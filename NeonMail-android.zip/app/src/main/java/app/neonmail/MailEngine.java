package app.neonmail;

import com.sun.mail.imap.AppendUID;
import com.sun.mail.imap.IMAPFolder;
import com.sun.mail.imap.IMAPStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.AuthenticationFailedException;
import javax.mail.BodyPart;
import javax.mail.FetchProfile;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.UIDFolder;
import javax.mail.internet.ContentType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;
import javax.mail.search.AndTerm;
import javax.mail.search.BodyTerm;
import javax.mail.search.FromStringTerm;
import javax.mail.search.HeaderTerm;
import javax.mail.search.OrTerm;
import javax.mail.search.RecipientStringTerm;
import javax.mail.search.SearchTerm;
import javax.mail.search.SubjectTerm;

/** IMAP/SMTP engine on top of JavaMail. Pure Java: no Android classes, so it can be tested on a desktop JVM. */
public class MailEngine {
    static {
        System.setProperty("mail.mime.decodetext.strict", "false");
        System.setProperty("mail.mime.decodefilename", "true");
        System.setProperty("mail.mime.encodefilename", "true");
        System.setProperty("mail.mime.address.strict", "false");
        System.setProperty("mail.mime.parameters.strict", "false");
        System.setProperty("mail.mime.charset", "UTF-8");
        System.setProperty("mail.mime.multipart.ignoreexistingboundaryparameter", "true");
    }

    /** account settings (password already decrypted) */
    public static class Acc {
        public String id, email, name = "", user, pass, imapHost, smtpHost, imapSec = "ssl", smtpSec = "ssl";
        public int imapPort = 993, smtpPort = 465;

        public static Acc from(JSONObject o, String pass) {
            Acc a = new Acc();
            a.id = o.optString("id"); a.email = o.optString("email"); a.name = o.optString("name", "");
            a.user = o.optString("user", a.email); a.pass = pass;
            a.imapHost = o.optString("imapHost"); a.imapPort = o.optInt("imapPort", 993); a.imapSec = o.optString("imapSec", "ssl");
            a.smtpHost = o.optString("smtpHost"); a.smtpPort = o.optInt("smtpPort", 465); a.smtpSec = o.optString("smtpSec", "ssl");
            return a;
        }
    }

    public static class MailError extends Exception {
        public MailError(String m, Throwable c) { super(m, c); }
    }

    final Map<String, IMAPStore> stores = new HashMap<>();
    final Map<String, Session> sessions = new HashMap<>();

    /* ======================= connection ======================= */
    Properties props(Acc a) {
        Properties p = new Properties();
        boolean issl = "ssl".equals(a.imapSec), ssl = "ssl".equals(a.smtpSec);
        String ip = issl ? "imaps" : "imap", sp = ssl ? "smtps" : "smtp";
        p.put("mail.store.protocol", ip);
        p.put("mail." + ip + ".host", a.imapHost);
        p.put("mail." + ip + ".port", String.valueOf(a.imapPort));
        p.put("mail." + ip + ".connectiontimeout", "20000");
        p.put("mail." + ip + ".timeout", "60000");
        p.put("mail." + ip + ".writetimeout", "60000");
        p.put("mail." + ip + ".partialfetch", "true");
        p.put("mail." + ip + ".fetchsize", "262144");
        p.put("mail." + ip + ".peek", "true");
        p.put("mail." + ip + ".connectionpoolsize", "3");
        p.put("mail." + ip + ".ssl.checkserveridentity", "true");
        if ("starttls".equals(a.imapSec)) { p.put("mail.imap.starttls.enable", "true"); p.put("mail.imap.starttls.required", "true"); }
        p.put("mail.transport.protocol", sp);
        p.put("mail." + sp + ".host", a.smtpHost);
        p.put("mail." + sp + ".port", String.valueOf(a.smtpPort));
        p.put("mail." + sp + ".auth", "true");
        p.put("mail." + sp + ".connectiontimeout", "20000");
        p.put("mail." + sp + ".timeout", "120000");
        p.put("mail." + sp + ".writetimeout", "120000");
        p.put("mail." + sp + ".ssl.checkserveridentity", "true");
        if ("starttls".equals(a.smtpSec)) { p.put("mail.smtp.starttls.enable", "true"); p.put("mail.smtp.starttls.required", "true"); }
        String dom = a.email.contains("@") ? a.email.substring(a.email.indexOf('@') + 1) : "localhost";
        p.put("mail." + sp + ".localhost", dom);
        return p;
    }

    synchronized Session session(Acc a) {
        Session s = sessions.get(a.id);
        if (s == null) { s = Session.getInstance(props(a)); sessions.put(a.id, s); }
        return s;
    }

    public synchronized IMAPStore store(Acc a) throws MailError {
        IMAPStore s = stores.get(a.id);
        try {
            if (s != null && s.isConnected()) return s;
            if (s == null) { s = (IMAPStore) session(a).getStore("ssl".equals(a.imapSec) ? "imaps" : "imap"); stores.put(a.id, s); }
            s.connect(a.imapHost, a.imapPort, a.user, a.pass);
            return s;
        } catch (MessagingException e) { stores.remove(a.id); throw friendly(e, false); }
    }

    public synchronized void forget(String accId) {
        IMAPStore s = stores.remove(accId);
        sessions.remove(accId);
        if (s != null) try { s.close(); } catch (Exception ignored) { }
    }

    public static MailError friendly(Exception e, boolean smtp) {
        String m = String.valueOf(e.getMessage());
        Throwable c = e;
        while (c.getCause() != null && c.getCause() != c) c = c.getCause();
        String cm = String.valueOf(c.getMessage()) + " " + c.getClass().getSimpleName();
        String low = (m + " " + cm).toLowerCase(Locale.ROOT);
        String msg;
        if (e instanceof AuthenticationFailedException || low.contains("authentication failed") || low.contains("invalid credentials") || low.contains("[auth") || low.contains("535") || low.contains("login failed"))
            msg = "Неверный логин или пароль. Почте нужен «пароль приложения», а не обычный пароль от аккаунта.";
        else if (low.contains("unknownhost") || low.contains("unable to resolve") || low.contains("no address associated"))
            msg = "Нет интернета или неверный адрес сервера.";
        else if (low.contains("refused") || low.contains("unreachable"))
            msg = "Не удалось подключиться к серверу " + (smtp ? "отправки" : "почты") + ". Проверьте интернет, адрес и порт.";
        else if (low.contains("timed out") || low.contains("timeout") || low.contains("couldn't connect"))
            msg = "Сервер не отвечает. Проверьте интернет и попробуйте ещё раз.";
        else if (low.contains("certificate") || low.contains("ssl") || low.contains("handshake"))
            msg = "Ошибка защищённого соединения (SSL). Проверьте настройки шифрования.";
        else if (low.contains("imap") && low.contains("disabled") || low.contains("not enabled"))
            msg = "Доступ по IMAP выключен в настройках почты. Включите его на сайте почты.";
        else msg = (smtp ? "Ошибка отправки: " : "Ошибка почты: ") + m;
        return new MailError(msg, e);
    }

    /* ======================= helpers ======================= */
    static String addrList(Address[] as) {
        if (as == null) return "";
        StringBuilder sb = new StringBuilder();
        for (Address a : as) {
            if (sb.length() > 0) sb.append(", ");
            if (a instanceof InternetAddress) { InternetAddress ia = (InternetAddress) a; sb.append(ia.getPersonal() != null && !ia.getPersonal().isEmpty() ? fixUtf8(ia.getPersonal()) + " <" + ia.getAddress() + ">" : ia.getAddress()); }
            else sb.append(a.toString());
        }
        return sb.toString();
    }

    static JSONArray addrJson(Address[] as) {
        JSONArray r = new JSONArray();
        if (as != null) for (Address a : as) {
            JSONObject o = new JSONObject();
            try {
                if (a instanceof InternetAddress) { InternetAddress ia = (InternetAddress) a; o.put("n", ia.getPersonal() == null ? "" : fixUtf8(ia.getPersonal())); o.put("a", ia.getAddress() == null ? "" : ia.getAddress()); }
                else { o.put("n", ""); o.put("a", a.toString()); }
            } catch (Exception ignored) { }
            r.put(o);
        }
        return r;
    }

    static String safe(Callable c) { try { String s = c.call(); return s == null ? "" : fixUtf8(s); } catch (Exception e) { return ""; } }

    /** some servers send raw UTF-8 in ENVELOPE/BODYSTRUCTURE; JavaMail reads it as Latin-1 — repair that */
    static String fixUtf8(String s) {
        if (s == null || s.isEmpty()) return s;
        boolean hi = false;
        for (int i = 0; i < s.length(); i++) { char c = s.charAt(i); if (c > 0xFF) return s; if (c >= 0x80) hi = true; }
        if (!hi) return s;
        try {
            java.nio.charset.CharsetDecoder d = StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT).onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT);
            return d.decode(java.nio.ByteBuffer.wrap(s.getBytes(StandardCharsets.ISO_8859_1))).toString();
        } catch (Exception e) { return s; }
    }

    interface Callable { String call() throws Exception; }

    static long uidOf(IMAPFolder f, Message m) { try { return f.getUID(m); } catch (Exception e) { return -1; } }

    /** header row for the list */
    static JSONObject row(IMAPFolder f, Message m) {
        JSONObject o = new JSONObject();
        try {
            o.put("uid", uidOf(f, m));
            String mid = "";
            try { String[] h = m.getHeader("Message-ID"); if (h != null && h.length > 0) mid = h[0]; } catch (Exception ignored) { }
            if (mid.isEmpty() && m instanceof MimeMessage) mid = safe(() -> ((MimeMessage) m).getMessageID());
            o.put("msgid", mid);
            Address[] from = null;
            try { from = m.getFrom(); } catch (Exception ignored) { }
            String fn = "", fa = "";
            if (from != null && from.length > 0 && from[0] instanceof InternetAddress) { InternetAddress ia = (InternetAddress) from[0]; fn = ia.getPersonal() == null ? "" : fixUtf8(ia.getPersonal()); fa = ia.getAddress() == null ? "" : ia.getAddress(); }
            o.put("fromName", fn); o.put("fromAddr", fa);
            o.put("to", safe(() -> addrList(m.getRecipients(Message.RecipientType.TO))));
            o.put("cc", safe(() -> addrList(m.getRecipients(Message.RecipientType.CC))));
            o.put("subject", safe(m::getSubject));
            Date d = null;
            try { d = m.getReceivedDate(); } catch (Exception ignored) { }
            if (d == null) try { d = m.getSentDate(); } catch (Exception ignored) { }
            o.put("date", d == null ? 0 : d.getTime());
            Flags fl = m.getFlags();
            o.put("seen", fl.contains(Flags.Flag.SEEN) ? 1 : 0);
            o.put("flagged", fl.contains(Flags.Flag.FLAGGED) ? 1 : 0);
            o.put("answered", fl.contains(Flags.Flag.ANSWERED) ? 1 : 0);
            o.put("draft", fl.contains(Flags.Flag.DRAFT) ? 1 : 0);
            o.put("size", Math.max(0, m.getSize()));
            boolean att = false;
            try { att = hasAttachments(m, 0); } catch (Exception bad) { try { String[] ct = m.getHeader("Content-Type"); att = ct != null && ct.length > 0 && ct[0].toLowerCase(Locale.ROOT).contains("multipart/mixed"); } catch (Exception ignored) { } }
            o.put("att", att ? 1 : 0);
        } catch (Exception ignored) { }
        return o;
    }

    static boolean hasAttachments(Part p, int depth) throws Exception {
        if (depth > 8) return false;
        if (p.isMimeType("multipart/*")) {
            Object c = p.getContent();
            if (!(c instanceof Multipart)) return false;
            Multipart mp = (Multipart) c;
            for (int i = 0; i < mp.getCount(); i++) if (hasAttachments(mp.getBodyPart(i), depth + 1)) return true;
            return false;
        }
        if (depth == 0) return false;
        String disp = null;
        try { disp = p.getDisposition(); } catch (Exception ignored) { }
        String fn = null;
        try { fn = p.getFileName(); } catch (Exception ignored) { }
        if (Part.ATTACHMENT.equalsIgnoreCase(disp)) return true;
        if (fn != null && !fn.isEmpty() && !p.isMimeType("image/*")) return true;
        return fn != null && !fn.isEmpty() && p instanceof MimeBodyPart && ((MimeBodyPart) p).getContentID() == null;
    }

    static FetchProfile headerProfile() {
        FetchProfile fp = new FetchProfile();
        fp.add(FetchProfile.Item.ENVELOPE);
        fp.add(FetchProfile.Item.FLAGS);
        fp.add(FetchProfile.Item.CONTENT_INFO);
        fp.add(FetchProfile.Item.SIZE);
        fp.add(UIDFolder.FetchProfileItem.UID);
        fp.add("Message-ID");
        fp.add("Content-Type");
        return fp;
    }

    IMAPFolder open(Acc a, String name, int mode) throws MailError {
        try {
            IMAPFolder f = (IMAPFolder) store(a).getFolder(name);
            f.open(mode);
            return f;
        } catch (MailError e) { throw e; }
        catch (MessagingException e) {
            // stale connection: reconnect once
            forget(a.id);
            try { IMAPFolder f = (IMAPFolder) store(a).getFolder(name); f.open(mode); return f; }
            catch (MessagingException e2) { throw friendly(e2, false); }
        }
    }

    static void close(Folder f) { if (f != null && f.isOpen()) try { f.close(false); } catch (Exception ignored) { } }

    static Message[] byUids(IMAPFolder f, long[] uids) throws MessagingException {
        Message[] ms = f.getMessagesByUID(uids);
        List<Message> l = new ArrayList<>();
        for (Message m : ms) if (m != null) l.add(m);
        return l.toArray(new Message[0]);
    }

    /* ======================= folders ======================= */
    public JSONArray folders(Acc a) throws MailError {
        JSONArray out = new JSONArray();
        try {
            IMAPStore s = store(a);
            Folder[] all = s.getDefaultFolder().list("*");
            for (Folder f0 : all) {
                IMAPFolder f = (IMAPFolder) f0;
                JSONObject o = new JSONObject();
                String[] attrs = new String[0];
                try { attrs = f.getAttributes(); } catch (Exception ignored) { }
                Set<String> at = new HashSet<>();
                for (String x : attrs) at.add(x.toLowerCase(Locale.ROOT));
                boolean noselect = at.contains("\\noselect") || at.contains("\\nonexistent");
                String full = f.getFullName();
                o.put("name", full);
                o.put("sep", String.valueOf(f.getSeparator()));
                o.put("role", role(full, at));
                o.put("noselect", noselect);
                if (!noselect) {
                    try { o.put("unread", f.getUnreadMessageCount()); o.put("total", f.getMessageCount()); } catch (Exception e) { o.put("unread", 0); o.put("total", 0); }
                }
                out.put(o);
            }
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); }
        return out;
    }

    static String role(String full, Set<String> at) {
        if (full.equalsIgnoreCase("INBOX")) return "inbox";
        if (at.contains("\\sent")) return "sent";
        if (at.contains("\\drafts")) return "drafts";
        if (at.contains("\\trash")) return "trash";
        if (at.contains("\\junk")) return "spam";
        if (at.contains("\\archive")) return "archive";
        if (at.contains("\\all")) return "all";
        if (at.contains("\\flagged")) return "flagged";
        if (at.contains("\\important")) return "important";
        String n = full.toLowerCase(Locale.ROOT);
        int i = Math.max(n.lastIndexOf('/'), n.lastIndexOf('.'));
        String leaf = i >= 0 ? n.substring(i + 1) : n;
        switch (leaf) {
            case "sent": case "sent items": case "sent messages": case "отправленные": return "sent";
            case "drafts": case "draft": case "черновики": return "drafts";
            case "trash": case "deleted": case "deleted items": case "deleted messages": case "корзина": case "удаленные": case "удалённые": return "trash";
            case "spam": case "junk": case "bulk mail": case "спам": return "spam";
            case "archive": case "archives": case "архив": return "archive";
            default: return "";
        }
    }

    /* ======================= list sync ======================= */
    /**
     * New messages since maxUid, flag changes and deletions inside the known window.
     * window = UIDs we already have cached (newest first).
     */
    public JSONObject sync(Acc a, String folder, long knownValidity, long maxUid, long[] window, int firstPage) throws MailError {
        IMAPFolder f = null;
        JSONObject r = new JSONObject();
        try {
            f = open(a, folder, Folder.READ_ONLY);
            long uv = f.getUIDValidity();
            boolean reset = knownValidity != 0 && uv != knownValidity;
            if (reset) { maxUid = 0; window = new long[0]; }
            r.put("uidvalidity", uv); r.put("reset", reset);
            int count = f.getMessageCount();
            Message[] fresh;
            if (count == 0) fresh = new Message[0];
            else if (maxUid > 0) {
                Message[] ms = f.getMessagesByUID(maxUid + 1, UIDFolder.LASTUID);
                List<Message> l = new ArrayList<>();
                FetchProfile up = new FetchProfile(); up.add(UIDFolder.FetchProfileItem.UID);
                f.fetch(ms, up);
                for (Message m : ms) if (m != null && uidOf(f, m) > maxUid) l.add(m);
                if (l.size() > 300) l = l.subList(l.size() - 300, l.size());
                fresh = l.toArray(new Message[0]);
            } else fresh = f.getMessages(Math.max(1, count - firstPage + 1), count);
            f.fetch(fresh, headerProfile());
            JSONArray rows = new JSONArray();
            for (int i = fresh.length - 1; i >= 0; i--) rows.put(row(f, fresh[i]));
            r.put("rows", rows);
            // flags + removals for the cached window
            JSONArray upd = new JSONArray(), gone = new JSONArray();
            if (window != null && window.length > 0) {
                long lo = Long.MAX_VALUE, hi = 0;
                for (long u : window) { lo = Math.min(lo, u); hi = Math.max(hi, u); }
                Message[] ms = f.getMessagesByUID(lo, hi);
                FetchProfile fp = new FetchProfile(); fp.add(FetchProfile.Item.FLAGS); fp.add(UIDFolder.FetchProfileItem.UID);
                f.fetch(ms, fp);
                Set<Long> present = new HashSet<>();
                for (Message m : ms) {
                    if (m == null) continue;
                    long u = uidOf(f, m);
                    present.add(u);
                    Flags fl = m.getFlags();
                    upd.put(new JSONArray().put(u).put(fl.contains(Flags.Flag.SEEN) ? 1 : 0).put(fl.contains(Flags.Flag.FLAGGED) ? 1 : 0).put(fl.contains(Flags.Flag.ANSWERED) ? 1 : 0));
                }
                for (long u : window) if (!present.contains(u)) gone.put(u);
            }
            r.put("flags", upd); r.put("gone", gone);
            r.put("total", count);
            r.put("unread", f.getUnreadMessageCount());
            return r;
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); } finally { close(f); }
    }

    /** older messages below minUid */
    public JSONArray older(Acc a, String folder, long minUid, int limit) throws MailError {
        IMAPFolder f = null;
        try {
            f = open(a, folder, Folder.READ_ONLY);
            int seq;
            Message m0 = minUid > 0 ? f.getMessageByUID(minUid) : null;
            if (m0 != null) seq = m0.getMessageNumber();
            else {
                // the boundary message disappeared: find the first message with a smaller uid
                Message[] ms = f.getMessagesByUID(1, Math.max(1, minUid - 1));
                if (ms.length == 0) return new JSONArray();
                seq = ms[ms.length - 1].getMessageNumber() + 1;
            }
            if (seq <= 1) return new JSONArray();
            Message[] ms = f.getMessages(Math.max(1, seq - limit), seq - 1);
            f.fetch(ms, headerProfile());
            JSONArray rows = new JSONArray();
            for (int i = ms.length - 1; i >= 0; i--) rows.put(row(f, ms[i]));
            return rows;
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); } finally { close(f); }
    }

    /* ======================= message body ======================= */
    static String decodeText(Part p) throws Exception {
        try {
            Object c = p.getContent();
            if (c instanceof String) return (String) c;
            if (c instanceof InputStream) return readAll((InputStream) c, "UTF-8");
        } catch (java.io.UnsupportedEncodingException e) { /* fall back below */ }
        String cs = "UTF-8";
        try { String ct = new ContentType(p.getContentType()).getParameter("charset"); if (ct != null) { String j = MimeUtility.javaCharset(ct); if (Charset.isSupported(j)) cs = j; } } catch (Exception ignored) { }
        return readAll(p.getInputStream(), cs);
    }

    static String readAll(InputStream in, String cs) throws IOException {
        try (InputStream i = in) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[16384]; int n;
            while ((n = i.read(b)) > 0) { bo.write(b, 0, n); if (bo.size() > 8 * 1024 * 1024) break; }
            return bo.toString(cs);
        }
    }

    static class Walk {
        String html, text;
        final List<JSONObject> atts = new ArrayList<>();
        final StringBuilder extraHtml = new StringBuilder();
    }

    static String fileName(Part p) {
        String fn = null;
        try { fn = p.getFileName(); } catch (Exception ignored) { }
        if (fn != null) { try { fn = MimeUtility.decodeText(fn); } catch (Exception ignored) { } fn = fixUtf8(fn); }
        return fn;
    }

    static void walk(Part p, String path, Walk w, int depth, boolean inAlt) throws Exception {
        if (depth > 10) return;
        if (p.isMimeType("multipart/*")) {
            Object c = p.getContent();
            if (!(c instanceof Multipart)) return;
            Multipart mp = (Multipart) c;
            boolean alt = p.isMimeType("multipart/alternative");
            if (alt) {
                // pick the richest alternative, attachments inside are still collected
                Part best = null, plain = null; String bestPath = null; int bestRank = -1;
                for (int i = 0; i < mp.getCount(); i++) {
                    BodyPart bp = mp.getBodyPart(i);
                    int rank = bp.isMimeType("text/plain") ? 1 : bp.isMimeType("text/html") ? 2 : bp.isMimeType("multipart/*") ? 3 : 0;
                    if (rank >= bestRank) { best = bp; bestRank = rank; bestPath = sub(path, i); }
                    if (bp.isMimeType("text/plain") && plain == null) plain = bp;
                }
                if (plain != null && plain != best && w.text == null) { try { w.text = decodeText(plain); } catch (Exception ignored) { } }
                if (best != null) walk(best, bestPath, w, depth + 1, true);
                return;
            }
            for (int i = 0; i < mp.getCount(); i++) walk(mp.getBodyPart(i), sub(path, i), w, depth + 1, inAlt);
            return;
        }
        String disp = null;
        try { disp = p.getDisposition(); } catch (Exception ignored) { }
        String fn = fileName(p);
        boolean isAtt = Part.ATTACHMENT.equalsIgnoreCase(disp) || (fn != null && !fn.isEmpty() && !p.isMimeType("text/plain") && !p.isMimeType("text/html"));
        if (!isAtt && p.isMimeType("text/html")) {
            String h = decodeText(p);
            if (w.html == null) w.html = h; else w.extraHtml.append("<hr>").append(h);
            return;
        }
        if (!isAtt && p.isMimeType("text/plain")) {
            String t = decodeText(p);
            if (w.text == null) w.text = t;
            else if (w.html == null) w.text = w.text + "\n\n" + t;
            else w.extraHtml.append("<pre>").append(escape(t)).append("</pre>");
            return;
        }
        if (!isAtt && p.isMimeType("text/calendar")) isAtt = true;
        // attachment or inline resource
        JSONObject o = new JSONObject();
        String cid = null;
        if (p instanceof MimeBodyPart) { try { cid = ((MimeBodyPart) p).getContentID(); } catch (Exception ignored) { } }
        if (cid != null) cid = cid.replaceAll("^<|>$", "");
        String mime = "application/octet-stream";
        try { mime = new ContentType(p.getContentType()).getBaseType().toLowerCase(Locale.ROOT); } catch (Exception ignored) { }
        if (fn == null || fn.isEmpty()) {
            if (p.isMimeType("message/rfc822")) fn = "Вложенное письмо.eml";
            else fn = (cid != null ? "image" : "attachment") + extFor(mime);
        }
        o.put("p", path); o.put("name", fn); o.put("mime", mime);
        int sz = -1;
        try { sz = p.getSize(); } catch (Exception ignored) { }
        String enc = null;
        try { String[] h = p.getHeader("Content-Transfer-Encoding"); if (h != null && h.length > 0) enc = h[0]; } catch (Exception ignored) { }
        if (sz > 0 && enc != null && enc.trim().equalsIgnoreCase("base64")) sz = sz * 3 / 4;
        o.put("size", sz);
        if (cid != null) o.put("cid", cid);
        o.put("inline", cid != null && !Part.ATTACHMENT.equalsIgnoreCase(disp));
        w.atts.add(o);
    }

    static String extFor(String mime) {
        switch (mime) {
            case "image/jpeg": return ".jpg";
            case "image/png": return ".png";
            case "image/gif": return ".gif";
            case "application/pdf": return ".pdf";
            case "text/calendar": return ".ics";
            default: return "";
        }
    }

    static String sub(String path, int i) { return path.isEmpty() ? String.valueOf(i) : path + "." + i; }

    static String escape(String s) { return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }

    public static String snippet(String text, String html) {
        String s = text;
        if ((s == null || s.trim().isEmpty()) && html != null) {
            s = html.replaceAll("(?is)<(style|script|head|title)[^>]*>.*?</\\1>", " ").replaceAll("(?s)<[^>]+>", " ")
                    .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replaceAll("&[a-zA-Z#0-9]+;", " ");
        }
        if (s == null) return "";
        s = s.replaceAll("(?m)^>.*$", " ").replaceAll("\\s+", " ").trim();
        return s.length() > 220 ? s.substring(0, 220) : s;
    }

    public JSONObject body(Acc a, String folder, long uid) throws MailError {
        IMAPFolder f = null;
        try {
            f = open(a, folder, Folder.READ_ONLY);
            Message m = f.getMessageByUID(uid);
            if (m == null) throw new MailError("Письмо не найдено — возможно, его удалили или переместили.", null);
            return bodyJson(m, uid);
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); } finally { close(f); }
    }

    /** several bodies with one folder open (list snippets) */
    public JSONArray bodies(Acc a, String folder, long[] uids) throws MailError {
        IMAPFolder f = null;
        JSONArray out = new JSONArray();
        try {
            f = open(a, folder, Folder.READ_ONLY);
            Message[] ms = f.getMessagesByUID(uids);
            for (int i = 0; i < ms.length; i++) {
                if (ms[i] == null) continue;
                try { out.put(bodyJson(ms[i], uids[i])); }
                catch (Exception e) { JSONObject o = new JSONObject(); o.put("uid", uids[i]); o.put("failed", true); out.put(o); }
            }
            return out;
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); } finally { close(f); }
    }

    static JSONObject bodyJson(Message m, long uid) throws Exception {
        {
            Walk w = new Walk();
            try { walk(m, "", w, 0, false); }
            catch (MessagingException bs) {
                // broken BODYSTRUCTURE from the server: download the whole message and parse it locally
                m = new MimeMessage((MimeMessage) m);
                w = new Walk();
                walk(m, "", w, 0, false);
            }
            JSONObject o = new JSONObject();
            o.put("uid", uid);
            String html = w.html;
            if (html != null && w.extraHtml.length() > 0) html = html + w.extraHtml;
            o.put("html", html == null ? "" : html);
            o.put("text", w.text == null ? "" : w.text);
            JSONArray atts = new JSONArray();
            for (JSONObject x : w.atts) atts.put(x);
            o.put("atts", atts);
            JSONObject hd = new JSONObject();
            hd.put("from", addrJson(m.getFrom()));
            hd.put("to", addrJson(m.getRecipients(Message.RecipientType.TO)));
            hd.put("cc", addrJson(m.getRecipients(Message.RecipientType.CC)));
            hd.put("bcc", addrJson(m.getRecipients(Message.RecipientType.BCC)));
            hd.put("replyTo", addrJson(m.getReplyTo()));
            hd.put("subject", safe(m::getSubject));
            Date d = m.getSentDate();
            if (d == null) d = m.getReceivedDate();
            hd.put("date", d == null ? 0 : d.getTime());
            hd.put("msgid", first(m, "Message-ID"));
            hd.put("refs", first(m, "References"));
            hd.put("irt", first(m, "In-Reply-To"));
            hd.put("listUnsub", first(m, "List-Unsubscribe"));
            o.put("hdr", hd);
            o.put("snippet", snippet(w.text, w.html));
            Flags fl = m.getFlags();
            o.put("seen", fl.contains(Flags.Flag.SEEN) ? 1 : 0);
            o.put("flagged", fl.contains(Flags.Flag.FLAGGED) ? 1 : 0);
            return o;
        }
    }

    static String first(Message m, String h) {
        try { String[] v = m.getHeader(h); return v == null || v.length == 0 ? "" : MimeUtility.unfold(v[0]).trim(); } catch (Exception e) { return ""; }
    }

    /** raw source of a message (for "показать оригинал" and .eml export) */
    public String source(Acc a, String folder, long uid, int max) throws MailError {
        IMAPFolder f = null;
        try {
            f = open(a, folder, Folder.READ_ONLY);
            Message m = f.getMessageByUID(uid);
            if (m == null) throw new MailError("Письмо не найдено", null);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            m.writeTo(bo);
            byte[] b = bo.toByteArray();
            return new String(b, 0, Math.min(b.length, max), StandardCharsets.UTF_8);
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); } finally { close(f); }
    }

    static Part partAt(Part p, String path) throws Exception {
        if (path == null || path.isEmpty()) return p;
        for (String s : path.split("\\.")) {
            Object c = p.getContent();
            if (!(c instanceof Multipart)) return null;
            Multipart mp = (Multipart) c;
            int i = Integer.parseInt(s);
            if (i >= mp.getCount()) return null;
            p = mp.getBodyPart(i);
        }
        return p;
    }

    static Part partByCid(Part p, String cid, int depth) throws Exception {
        if (depth > 10) return null;
        if (p.isMimeType("multipart/*")) {
            Object c = p.getContent();
            if (!(c instanceof Multipart)) return null;
            Multipart mp = (Multipart) c;
            for (int i = 0; i < mp.getCount(); i++) { Part r = partByCid(mp.getBodyPart(i), cid, depth + 1); if (r != null) return r; }
            return null;
        }
        if (p instanceof MimeBodyPart) {
            String id = ((MimeBodyPart) p).getContentID();
            if (id != null && id.replaceAll("^<|>$", "").equalsIgnoreCase(cid)) return p;
        }
        return null;
    }

    /** save an attachment (by part path, or by Content-ID when path starts with "cid:") into target file */
    public File savePart(Acc a, String folder, long uid, String path, File target) throws MailError {
        IMAPFolder f = null;
        try {
            f = open(a, folder, Folder.READ_ONLY);
            Message m = f.getMessageByUID(uid);
            if (m == null) throw new MailError("Письмо не найдено", null);
            Part p;
            try { p = path.startsWith("cid:") ? partByCid(m, path.substring(4), 0) : partAt(m, path); }
            catch (MessagingException bs) { Message lm = new MimeMessage((MimeMessage) m); p = path.startsWith("cid:") ? partByCid(lm, path.substring(4), 0) : partAt(lm, path); }
            if (p == null) throw new MailError("Вложение не найдено", null);
            File dir = target.getParentFile();
            if (dir != null) dir.mkdirs();
            File tmp = new File(target.getPath() + ".part");
            try (InputStream in = p.isMimeType("message/rfc822") ? rawStream(p) : p.getInputStream(); OutputStream out = new FileOutputStream(tmp)) {
                byte[] b = new byte[65536]; int n;
                while ((n = in.read(b)) > 0) out.write(b, 0, n);
            }
            if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target); }
            return target;
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); } finally { close(f); }
    }

    static InputStream rawStream(Part p) throws Exception {
        Object c = p.getContent();
        if (c instanceof Message) { ByteArrayOutputStream bo = new ByteArrayOutputStream(); ((Message) c).writeTo(bo); return new java.io.ByteArrayInputStream(bo.toByteArray()); }
        return p.getInputStream();
    }

    /* ======================= changes ======================= */
    public void flags(Acc a, String folder, long[] uids, String flag, boolean value) throws MailError {
        IMAPFolder f = null;
        try {
            f = open(a, folder, Folder.READ_WRITE);
            Message[] ms = byUids(f, uids);
            Flags.Flag fl = "seen".equals(flag) ? Flags.Flag.SEEN : "flagged".equals(flag) ? Flags.Flag.FLAGGED : "answered".equals(flag) ? Flags.Flag.ANSWERED : Flags.Flag.DELETED;
            if (ms.length > 0) f.setFlags(ms, new Flags(fl), value);
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); } finally { close(f); }
    }

    public void move(Acc a, String folder, long[] uids, String target) throws MailError {
        IMAPFolder f = null;
        try {
            f = open(a, folder, Folder.READ_WRITE);
            Message[] ms = byUids(f, uids);
            if (ms.length == 0) return;
            IMAPStore s = store(a);
            Folder t = s.getFolder(target);
            if (!t.exists()) t.create(Folder.HOLDS_MESSAGES);
            if (s.hasCapability("MOVE")) f.moveMessages(ms, t);
            else {
                f.copyMessages(ms, t);
                f.setFlags(ms, new Flags(Flags.Flag.DELETED), true);
                if (s.hasCapability("UIDPLUS")) f.expunge(ms); else f.expunge();
            }
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); } finally { close(f); }
    }

    /** permanent delete */
    public void destroy(Acc a, String folder, long[] uids) throws MailError {
        IMAPFolder f = null;
        try {
            f = open(a, folder, Folder.READ_WRITE);
            Message[] ms = byUids(f, uids);
            if (ms.length == 0) return;
            f.setFlags(ms, new Flags(Flags.Flag.DELETED), true);
            if (store(a).hasCapability("UIDPLUS")) f.expunge(ms); else f.expunge();
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); } finally { close(f); }
    }

    /** delete everything in a folder (Trash / Spam "empty" button) */
    public void emptyFolder(Acc a, String folder) throws MailError {
        IMAPFolder f = null;
        try {
            f = open(a, folder, Folder.READ_WRITE);
            int n = f.getMessageCount();
            if (n > 0) { f.setFlags(1, n, new Flags(Flags.Flag.DELETED), true); f.expunge(); }
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); } finally { close(f); }
    }

    public void markAllRead(Acc a, String folder) throws MailError {
        IMAPFolder f = null;
        try {
            f = open(a, folder, Folder.READ_WRITE);
            int n = f.getMessageCount();
            if (n > 0) f.setFlags(1, n, new Flags(Flags.Flag.SEEN), true);
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); } finally { close(f); }
    }

    public void deleteFolder(Acc a, String name) throws MailError {
        try { Folder t = store(a).getFolder(name); if (t.exists() && !t.delete(true)) throw new MailError("Сервер не разрешил удалить папку", null); }
        catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); }
    }

    public void createFolder(Acc a, String name) throws MailError {
        try { Folder t = store(a).getFolder(name); if (!t.exists() && !t.create(Folder.HOLDS_MESSAGES)) throw new MailError("Сервер не разрешил создать папку", null); }
        catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); }
    }

    public long append(Acc a, String folder, MimeMessage msg, boolean seen, boolean draft) throws MailError {
        IMAPFolder f = null;
        try {
            f = (IMAPFolder) store(a).getFolder(folder);
            if (!f.exists()) f.create(Folder.HOLDS_MESSAGES);
            Flags fl = new Flags();
            if (seen) fl.add(Flags.Flag.SEEN);
            if (draft) fl.add(Flags.Flag.DRAFT);
            msg.setFlags(fl, true);
            AppendUID[] r = f.appendUIDMessages(new Message[]{msg});
            return r != null && r.length > 0 && r[0] != null ? r[0].uid : -1;
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); } finally { close(f); }
    }

    /* ======================= search ======================= */
    public JSONArray search(Acc a, String folder, String q, int limit) throws MailError {
        IMAPFolder f = null;
        try {
            f = open(a, folder, Folder.READ_ONLY);
            List<SearchTerm> ands = new ArrayList<>();
            for (String w : q.trim().split("\\s+")) {
                if (w.isEmpty()) continue;
                ands.add(new OrTerm(new SearchTerm[]{new FromStringTerm(w), new SubjectTerm(w), new RecipientStringTerm(Message.RecipientType.TO, w), new BodyTerm(w)}));
            }
            if (ands.isEmpty()) return new JSONArray();
            SearchTerm t = ands.size() == 1 ? ands.get(0) : new AndTerm(ands.toArray(new SearchTerm[0]));
            Message[] ms = f.search(t);
            if (ms.length > limit) ms = Arrays.copyOfRange(ms, ms.length - limit, ms.length);
            f.fetch(ms, headerProfile());
            JSONArray rows = new JSONArray();
            for (int i = ms.length - 1; i >= 0; i--) rows.put(row(f, ms[i]));
            return rows;
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); } finally { close(f); }
    }

    /** headers of new INBOX messages (for notifications) */
    public JSONObject newSince(Acc a, String folder, long lastUid) throws MailError {
        IMAPFolder f = null;
        try {
            f = open(a, folder, Folder.READ_ONLY);
            JSONObject r = new JSONObject();
            long next = f.getUIDNext();
            r.put("uidnext", next);
            JSONArray rows = new JSONArray();
            if (lastUid > 0 && next > lastUid + 1) {
                Message[] ms = f.getMessagesByUID(lastUid + 1, UIDFolder.LASTUID);
                f.fetch(ms, headerProfile());
                for (Message m : ms) if (m != null && uidOf(f, m) > lastUid) rows.put(row(f, m));
            }
            r.put("rows", rows);
            return r;
        } catch (MailError e) { throw e; } catch (Exception e) { throw friendly(e, false); } finally { close(f); }
    }

    /* ======================= compose & send ======================= */
    static InternetAddress[] parseAddrs(String s) throws Exception {
        if (s == null || s.trim().isEmpty()) return new InternetAddress[0];
        InternetAddress[] r = InternetAddress.parse(s.replace(';', ','), false);
        for (InternetAddress x : r) {
            if (x.getPersonal() != null) x.setPersonal(x.getPersonal(), "UTF-8");
            if (x.getAddress() == null || !x.getAddress().contains("@")) throw new MailError("Неверный адрес: " + x, null);
        }
        return r;
    }

    /**
     * j: {to, cc, bcc, subject, html, text, irt, refs}; files: attachments (name taken from File, or from names list)
     */
    public MimeMessage build(Acc a, JSONObject j, List<File> files, List<String> names) throws Exception {
        MimeMessage m = new MimeMessage(session(a)) {
            @Override protected void updateMessageID() throws MessagingException {
                if (getHeader("Message-ID") == null) super.updateMessageID();
            }
        };
        m.setFrom(new InternetAddress(a.email, a.name == null || a.name.isEmpty() ? null : a.name, "UTF-8"));
        m.setRecipients(Message.RecipientType.TO, parseAddrs(j.optString("to")));
        InternetAddress[] cc = parseAddrs(j.optString("cc")), bcc = parseAddrs(j.optString("bcc"));
        if (cc.length > 0) m.setRecipients(Message.RecipientType.CC, cc);
        if (bcc.length > 0) m.setRecipients(Message.RecipientType.BCC, bcc);
        m.setSubject(j.optString("subject", ""), "UTF-8");
        m.setSentDate(new Date());
        String irt = j.optString("irt", ""), refs = j.optString("refs", "");
        if (!irt.isEmpty()) m.setHeader("In-Reply-To", irt);
        if (!refs.isEmpty()) m.setHeader("References", MimeUtility.fold(12, refs));
        m.setHeader("X-Mailer", "Neon Mail");
        String dom = a.email.contains("@") ? a.email.substring(a.email.indexOf('@') + 1) : "neonmail.local";
        m.setHeader("Message-ID", "<" + java.util.UUID.randomUUID().toString().replace("-", "") + "@" + dom + ">");
        MimeBodyPart text = new MimeBodyPart();
        text.setText(j.optString("text", ""), "UTF-8");
        String html = j.optString("html", "");
        Multipart body;
        if (!html.isEmpty()) {
            MimeMultipart alt = new MimeMultipart("alternative");
            alt.addBodyPart(text);
            MimeBodyPart hp = new MimeBodyPart();
            hp.setContent("<!doctype html><html><head><meta charset=\"utf-8\"></head><body>" + html + "</body></html>", "text/html; charset=UTF-8");
            alt.addBodyPart(hp);
            body = alt;
        } else {
            body = null;
        }
        if (files == null || files.isEmpty()) {
            if (body != null) m.setContent(body); else m.setText(j.optString("text", ""), "UTF-8");
        } else {
            MimeMultipart mixed = new MimeMultipart("mixed");
            MimeBodyPart first = new MimeBodyPart();
            if (body != null) first.setContent(body); else first.setText(j.optString("text", ""), "UTF-8");
            mixed.addBodyPart(first);
            for (int i = 0; i < files.size(); i++) {
                File fl = files.get(i);
                MimeBodyPart ap = new MimeBodyPart();
                ap.setDataHandler(new DataHandler(new FileDataSource(fl)));
                String nm = names != null && i < names.size() && names.get(i) != null ? names.get(i) : fl.getName();
                ap.setFileName(MimeUtility.encodeText(nm, "UTF-8", null));
                ap.setDisposition(Part.ATTACHMENT);
                mixed.addBodyPart(ap);
            }
            m.setContent(mixed);
        }
        m.saveChanges();
        return m;
    }

    public void testSmtp(Acc a) throws MailError {
        Transport t = null;
        try {
            t = session(a).getTransport("ssl".equals(a.smtpSec) ? "smtps" : "smtp");
            t.connect(a.smtpHost, a.smtpPort, a.user, a.pass);
        } catch (Exception e) { throw friendly(e, true); }
        finally { if (t != null) try { t.close(); } catch (Exception ignored) { } }
    }

    /** send via SMTP, then make sure a copy is in Sent (some servers add it themselves) */
    public JSONObject send(Acc a, MimeMessage m, String sentFolder) throws MailError {
        Transport t = null;
        try {
            t = session(a).getTransport("ssl".equals(a.smtpSec) ? "smtps" : "smtp");
            t.connect(a.smtpHost, a.smtpPort, a.user, a.pass);
            t.sendMessage(m, m.getAllRecipients());
        } catch (Exception e) { throw friendly(e, true); }
        finally { if (t != null) try { t.close(); } catch (Exception ignored) { } }
        JSONObject r = new JSONObject();
        String mid = "";
        try { mid = m.getMessageID(); r.put("msgid", mid); } catch (Exception ignored) { }
        if (sentFolder != null && !sentFolder.isEmpty()) {
            try {
                boolean found = false;
                if (!a.imapHost.toLowerCase(Locale.ROOT).contains("gmail")) {
                    for (int i = 0; i < 2 && !found; i++) {
                        Thread.sleep(i == 0 ? 1200 : 2000);
                        found = existsByMsgId(a, sentFolder, mid);
                    }
                } else found = true;
                if (!found) append(a, sentFolder, m, true, false);
                r.put("copied", !found);
            } catch (Exception e) { try { r.put("copyError", e.getMessage()); } catch (Exception ignored) { } }
        }
        return r;
    }

    boolean existsByMsgId(Acc a, String folder, String mid) throws Exception {
        if (mid == null || mid.isEmpty()) return false;
        IMAPFolder f = null;
        try {
            f = open(a, folder, Folder.READ_ONLY);
            return f.search(new HeaderTerm("Message-ID", mid)).length > 0;
        } finally { close(f); }
    }

}
