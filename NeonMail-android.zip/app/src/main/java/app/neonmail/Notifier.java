package app.neonmail;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;

import org.json.JSONObject;

import java.util.List;

/** New-mail notifications with "Прочитано" / "Удалить" actions. */
public class Notifier extends BroadcastReceiver {
    static final String CH_MAIL = "mail", CH_SYS = "system";
    static final String A_READ = "app.neonmail.READ", A_TRASH = "app.neonmail.TRASH";

    static void channels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CH_MAIL) == null) {
            NotificationChannel ch = new NotificationChannel(CH_MAIL, "Новые письма", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Уведомления о новых письмах во входящих");
            ch.enableLights(true);
            ch.setLightColor(Color.parseColor("#36e2ff"));
            nm.createNotificationChannel(ch);
        }
        if (nm.getNotificationChannel(CH_SYS) == null)
            nm.createNotificationChannel(new NotificationChannel(CH_SYS, "Ошибки отправки", NotificationManager.IMPORTANCE_DEFAULT));
    }

    static int nid(String acc, String folder, long uid) { return (acc + "|" + folder + "|" + uid).hashCode() & 0x7fffffff; }

    static PendingIntent openIntent(Context c, String acc, String folder, long uid, int req) {
        Intent i = new Intent(c, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        i.putExtra("open_acc", acc);
        i.putExtra("open_folder", folder);
        i.putExtra("open_uid", uid);
        return PendingIntent.getActivity(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static PendingIntent action(Context c, String act, String acc, String folder, long uid, int req) {
        Intent i = new Intent(c, Notifier.class);
        i.setAction(act);
        i.putExtra("acc", acc);
        i.putExtra("folder", folder);
        i.putExtra("uid", uid);
        return PendingIntent.getBroadcast(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    @SuppressWarnings("deprecation")
    static void newMail(Context c, JSONObject acc, String folder, List<JSONObject> rows, boolean showAccount) {
        channels(c);
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= 24 && !nm.areNotificationsEnabled()) return;
        String id = acc.optString("id"), group = "acc_" + id;
        int color;
        try { color = Color.parseColor(acc.optString("color", "#36e2ff")); } catch (Exception e) { color = Color.parseColor("#36e2ff"); }
        for (JSONObject r : rows) {
            long uid = r.optLong("uid");
            int n = nid(id, folder, uid);
            String from = r.optString("fromName").isEmpty() ? r.optString("fromAddr") : r.optString("fromName");
            String subj = r.optString("subject").isEmpty() ? "(без темы)" : r.optString("subject");
            String snip = r.optString("snippet");
            Notification.Builder b = new Notification.Builder(c, CH_MAIL)
                    .setSmallIcon(R.drawable.ic_notif)
                    .setColor(color)
                    .setContentTitle(from)
                    .setContentText(subj)
                    .setStyle(new Notification.BigTextStyle().bigText(snip.isEmpty() ? subj : subj + "\n" + snip))
                    .setWhen(r.optLong("date") > 0 ? r.optLong("date") : System.currentTimeMillis())
                    .setShowWhen(true)
                    .setCategory(Notification.CATEGORY_EMAIL)
                    .setAutoCancel(true)
                    .setGroup(group)
                    .setContentIntent(openIntent(c, id, folder, uid, n))
                    .addAction(new Notification.Action.Builder((android.graphics.drawable.Icon) null, "Прочитано", action(c, A_READ, id, folder, uid, n + 1)).build())
                    .addAction(new Notification.Action.Builder((android.graphics.drawable.Icon) null, "Удалить", action(c, A_TRASH, id, folder, uid, n + 2)).build());
            if (showAccount) b.setSubText(acc.optString("email"));
            nm.notify(n, b.build());
        }
        if (rows.size() > 1 || nm.getActiveNotifications().length > 1) {
            Notification.InboxStyle st = new Notification.InboxStyle();
            for (JSONObject r : rows) st.addLine((r.optString("fromName").isEmpty() ? r.optString("fromAddr") : r.optString("fromName")) + "  " + r.optString("subject"));
            st.setSummaryText(acc.optString("email"));
            Notification sum = new Notification.Builder(c, CH_MAIL)
                    .setSmallIcon(R.drawable.ic_notif)
                    .setColor(color)
                    .setContentTitle("Новые письма")
                    .setContentText(acc.optString("email"))
                    .setStyle(st)
                    .setGroup(group)
                    .setGroupSummary(true)
                    .setAutoCancel(true)
                    .setContentIntent(openIntent(c, id, folder, 0, (group).hashCode()))
                    .build();
            nm.notify(group.hashCode() & 0x7fffffff, sum);
        }
    }

    static void sendFailed(Context c, String subject, String error) {
        channels(c);
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        Intent i = new Intent(c, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Notification n = new Notification.Builder(c, CH_SYS)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Письмо не отправлено")
                .setContentText((subject == null || subject.isEmpty() ? "(без темы)" : subject) + " — сохранено в черновиках")
                .setStyle(new Notification.BigTextStyle().bigText(error + "\nПисьмо сохранено в «Черновиках»."))
                .setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(c, 9, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE))
                .build();
        nm.notify(9, n);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        final String acc = i.getStringExtra("acc"), folder = i.getStringExtra("folder"), act = i.getAction();
        final long uid = i.getLongExtra("uid", 0);
        if (acc == null || folder == null || uid <= 0) return;
        final PendingResult pr = goAsync();
        final Core core = Core.get(c);
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        nm.cancel(nid(acc, folder, uid));
        core.net.execute(() -> {
            try {
                JSONObject a = new JSONObject();
                a.put("acc", acc); a.put("folder", folder); a.put("uids", new org.json.JSONArray().put(uid));
                if (A_READ.equals(act)) { a.put("flag", "seen"); a.put("value", true); core.flag(a); }
                else if (A_TRASH.equals(act)) core.remove(a);
                JSONObject e = Core.ev("changed");
                e.put("acc", acc); e.put("folder", folder);
                core.emit(e);
            } catch (Exception ignored) {
            } finally { pr.finish(); }
        });
    }
}
