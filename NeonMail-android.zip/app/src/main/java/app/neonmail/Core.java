package app.neonmail;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import javax.activation.CommandMap;
import javax.activation.MailcapCommandMap;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/** App-wide mail logic shared by the screen, the background checker and notification actions. */
final class Core {
    interface Listener { void emit(JSONObject ev); boolean isForeground(); }

    interface Host {
        void openFile(File f, String mime);
        void shareFile(File f, String mime);
        String saveDownload(File f, String name, String mime) throws Exception;
    }

    private static Core inst;

    static synchronized Core get(Context c) {
        if (inst == null) inst = new Core(c.getApplicationContext());
        return inst;
    }

    final Context ctx;
    final MailEngine eng = new MailEngine();
    final MailDb db;
    final ExecutorService net, bg;
    final ScheduledExecutorService sched;
    final Set<String> pendingSends = ConcurrentHashMap.newKeySet();
    final Set<String> prefetching = ConcurrentHashMap.newKeySet();
    final Map<String, MailEngine.Acc> accCache = new HashMap<>();
    volatile Listener listener;
    private int seq = 0;

    private Core(Context c) {
        ctx = c;
        db = new MailDb(c);
        ThreadFactory tf = r -> {
            Thread t = new Thread(() -> { Thread.currentThread().setContextClassLoader(Core.class.getClassLoader()); r.run(); });
            t.setDaemon(true);
            return t;
        };
        net = Executors.newFixedThreadPool(5, tf);
        bg = Executors.newSingleThreadExecutor(tf);
        sched = Executors.newSingleThreadScheduledExecutor(tf);
        setupMailcap();
    }

    static void setupMailcap() {
        try {
            MailcapCommandMap mc = (MailcapCommandMap) CommandMap.getDefaultCommandMap();
            mc.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
            mc.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
            mc.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
            mc.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed; x-java-fallback-entry=true");
            mc.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822");
            CommandMap.setDefaultCommandMap(mc);
        } catch (Throwable ignored) { }
    }

    void emit(JSONObject ev) { Listener l = listener; if (l != null) l.emit(ev); }

    boolean foreground() { Listener l = listener; return l != null && l.isForeground(); }

    static JSONObject ev(String type) { JSONObject o = new JSONObject(); try { o.put("type", type); } catch (Exception ignored) { } return o; }

    /* ======================= accounts ======================= */
    SharedPreferences prefs() { return ctx.getSharedPreferences("mail", Context.MODE_PRIVATE); }

    synchronized JSONArray accounts() {
        try { return new JSONArray(prefs().getString("accounts", "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    synchronized void saveAccounts(JSONArray a) { prefs().edit().putString("accounts", a.toString()).commit(); }

    JSONObject accJson(String id) {
        JSONArray a = accounts();
        for (int i = 0; i < a.length(); i++) if (id.equals(a.optJSONObject(i).optString("id"))) return a.optJSONObject(i);
        return null;
    }

    MailEngine.Acc acc(String id) throws MailEngine.MailError {
        synchronized (accCache) {
            MailEngine.Acc c = accCache.get(id);
            if (c != null) return c;
        }
        JSONObject o = accJson(id);
        if (o == null) throw new MailEngine.MailError("Почтовый ящик не найден", null);
        MailEngine.Acc a = MailEngine.Acc.from(o, Secret.dec(prefs().getString("pw_" + id, "")));
        synchronized (accCache) { accCache.put(id, a); }
        return a;
    }

    static final String[] COLORS = {"#ff4fd8", "#36e2ff", "#a970ff", "#a8ff3e", "#ff9f43", "#ff4f6d", "#ffc857", "#4f7dff"};

    static String cleanPass(String p) {
        if (p == null) return "";
        // app passwords are shown in groups ("abcd efgh ijkl mnop"); the servers want them without spaces
        if (p.trim().matches("([A-Za-z0-9]{4} ){3}[A-Za-z0-9]{4}")) return p.replace(" ", "");
        return p;
    }

    JSONObject addAccount(JSONObject a) throws Exception {
        String id = a.optString("id");
        JSONObject old = id.isEmpty() ? null : accJson(id);
        String email = a.optString("email").trim();
        if (!email.matches("[^@\\s]+@[^@\\s]+\\.[^@\\s]+")) throw new MailEngine.MailError("Проверьте адрес почты", null);
        JSONArray all = accounts();
        if (old == null) {
            for (int i = 0; i < all.length(); i++)
                if (all.optJSONObject(i).optString("email").equalsIgnoreCase(email)) throw new MailEngine.MailError("Этот ящик уже добавлен", null);
            id = "a" + System.currentTimeMillis();
        }
        JSONObject o = old != null ? new JSONObject(old.toString()) : new JSONObject();
        o.put("id", id);
        o.put("email", email);
        o.put("name", a.optString("name", o.optString("name", "")).trim());
        o.put("user", a.optString("user", email).trim().isEmpty() ? email : a.optString("user", email).trim());
        for (String k : new String[]{"imapHost", "smtpHost", "imapSec", "smtpSec", "provider"}) o.put(k, a.optString(k, o.optString(k)).trim());
        o.put("imapPort", a.optInt("imapPort", o.optInt("imapPort", 993)));
        o.put("smtpPort", a.optInt("smtpPort", o.optInt("smtpPort", 465)));
        if (!o.has("color")) o.put("color", a.optString("color", COLORS[all.length() % COLORS.length]));
        if (!o.has("signature")) o.put("signature", "");
        if (!o.has("notify")) o.put("notify", true);
        String pass = cleanPass(a.optString("pass"));
        if (pass.isEmpty() && old != null) pass = Secret.dec(prefs().getString("pw_" + id, ""));
        if (pass.isEmpty()) throw new MailEngine.MailError("Введите пароль приложения", null);
        MailEngine.Acc test = MailEngine.Acc.from(o, pass);
        test.id = "test-" + id;
        JSONArray fs;
        try {
            fs = eng.folders(test);
            try { eng.testSmtp(test); }
            catch (MailEngine.MailError se) { throw new MailEngine.MailError("Входящие работают, но сервер отправки (SMTP) ответил ошибкой: " + se.getMessage(), se); }
        } finally { eng.forget(test.id); }
        eng.forget(id);
        JSONArray out = new JSONArray();
        boolean replaced = false;
        for (int i = 0; i < all.length(); i++) {
            JSONObject x = all.optJSONObject(i);
            if (x.optString("id").equals(id)) { out.put(o); replaced = true; } else out.put(x);
        }
        if (!replaced) out.put(o);
        prefs().edit().putString("pw_" + id, Secret.enc(pass)).commit();
        saveAccounts(out);
        synchronized (accCache) { accCache.remove(id); }
        db.upsertFolders(id, fs);
        JSONObject r = new JSONObject();
        r.put("account", o);
        r.put("folders", db.folders(id));
        return r;
    }

    JSONObject updateAccount(JSONObject a) throws Exception {
        String id = a.getString("id");
        JSONArray all = accounts(), out = new JSONArray();
        JSONObject res = null;
        for (int i = 0; i < all.length(); i++) {
            JSONObject x = all.optJSONObject(i);
            if (x.optString("id").equals(id)) {
                for (String k : new String[]{"name", "signature", "color"}) if (a.has(k)) x.put(k, a.optString(k));
                if (a.has("notify")) x.put("notify", a.optBoolean("notify"));
                res = x;
            }
            out.put(x);
        }
        if (a.has("order")) {
            // reorder accounts: "order" = array of ids
            JSONArray ord = a.getJSONArray("order"), sorted = new JSONArray();
            for (int i = 0; i < ord.length(); i++) for (int j = 0; j < out.length(); j++) if (out.optJSONObject(j).optString("id").equals(ord.optString(i))) sorted.put(out.optJSONObject(j));
            if (sorted.length() == out.length()) out = sorted;
        }
        saveAccounts(out);
        synchronized (accCache) { accCache.remove(id); }
        return res;
    }

    void removeAccount(String id) {
        JSONArray all = accounts(), out = new JSONArray();
        for (int i = 0; i < all.length(); i++) if (!all.optJSONObject(i).optString("id").equals(id)) out.put(all.optJSONObject(i));
        saveAccounts(out);
        prefs().edit().remove("pw_" + id).remove("nl_" + id).commit();
        synchronized (accCache) { accCache.remove(id); }
        eng.forget(id);
        db.deleteAccount(id);
    }

    /* ======================= folders & lists ======================= */
    JSONArray folders(String acc, boolean refresh) throws Exception {
        JSONArray cur = db.folders(acc);
        if (refresh || cur.length() == 0) {
            db.upsertFolders(acc, eng.folders(acc(acc)));
            cur = db.folders(acc);
        }
        return cur;
    }

    boolean isGmail(String acc) {
        JSONObject o = accJson(acc);
        return o != null && o.optString("imapHost").toLowerCase(Locale.ROOT).contains("gmail");
    }

    /** "@trash", "@archive", ... → real folder name (created when missing) */
    String target(String acc, String t) throws Exception {
        if (!t.startsWith("@")) return t;
        String role = t.substring(1);
        String f = db.folderByRole(acc, role);
        if (f == null && role.equals("archive") && isGmail(acc)) f = db.folderByRole(acc, "all");
        if (f == null) {
            folders(acc, true);
            f = db.folderByRole(acc, role);
            if (f == null && role.equals("archive") && isGmail(acc)) f = db.folderByRole(acc, "all");
        }
        if (f == null) {
            switch (role) {
                case "inbox": f = "INBOX"; break;
                case "trash": f = "Trash"; break;
                case "spam": f = "Spam"; break;
                case "drafts": f = "Drafts"; break;
                case "sent": f = "Sent"; break;
                default: f = "Archive";
            }
            if (!f.equals("INBOX")) eng.createFolder(acc(acc), f);
            folders(acc, true);
        }
        return f;
    }

    JSONObject syncOne(String acc, String folder) throws Exception {
        if (folder == null || folder.isEmpty()) folder = target(acc, "@inbox");
        long[] st = db.folderState(acc, folder);
        long[] win = db.window(acc, folder, 400);
        JSONObject r = eng.sync(acc(acc), folder, st[0], st[1], win, 40);
        int added = db.applySync(acc, folder, r);
        JSONObject out = new JSONObject();
        out.put("acc", acc); out.put("folder", folder);
        out.put("added", added);
        out.put("gone", r.optJSONArray("gone") == null ? 0 : r.optJSONArray("gone").length());
        out.put("unread", r.optInt("unread")); out.put("total", r.optInt("total"));
        out.put("rows", r.optJSONArray("rows"));
        out.put("first", st[0] == 0 || r.optBoolean("reset"));
        prefetch(acc, folder);
        return out;
    }

    JSONObject sync(String acc, String folder) throws Exception {
        if (!"*".equals(acc)) { JSONObject r = syncOne(acc, folder); r.remove("rows"); return r; }
        JSONObject res = new JSONObject();
        int added = 0;
        JSONArray errors = new JSONArray(), all = accounts();
        for (int i = 0; i < all.length(); i++) {
            String id = all.optJSONObject(i).optString("id");
            try { added += syncOne(id, target(id, "@inbox")).optInt("added"); }
            catch (Exception e) { errors.put(all.optJSONObject(i).optString("email") + ": " + e.getMessage()); }
        }
        res.put("added", added);
        res.put("errors", errors);
        if (errors.length() > 0 && errors.length() == all.length()) throw new MailEngine.MailError(errors.optString(0), null);
        return res;
    }

    JSONObject more(String acc, String folder) throws Exception {
        long min = db.minUid(acc, folder);
        JSONObject r = new JSONObject();
        if (min <= 1) { r.put("added", 0); r.put("done", true); return r; }
        JSONArray rows = eng.older(acc(acc), folder, min, 40);
        r.put("added", db.insertRows(acc, folder, rows));
        r.put("done", rows.length() == 0);
        prefetch(acc, folder);
        return r;
    }

    /** load bodies of the newest messages in the background so the list shows text previews */
    void prefetch(String acc, String folder) {
        String key = acc + "|" + folder;
        if (!prefetching.add(key)) return;
        bg.execute(() -> {
            try {
                for (int round = 0; round < 3; round++) {
                    long[] us = db.needSnippets(acc, folder, 12);
                    if (us.length == 0) break;
                    JSONArray bs = eng.bodies(acc(acc), folder, us);
                    java.util.Set<Long> done = new java.util.HashSet<>();
                    for (int i = 0; i < bs.length(); i++) {
                        JSONObject b = bs.optJSONObject(i);
                        long u = b.optLong("uid");
                        done.add(u);
                        if (b.optBoolean("failed")) { b.put("snippet", ""); db.putSnippetOnly(acc, folder, u, ""); }
                        else db.putBody(acc, folder, u, b);
                    }
                    for (long u : us) if (!done.contains(u)) db.putSnippetOnly(acc, folder, u, "");
                    JSONObject e = ev("changed");
                    e.put("acc", acc); e.put("folder", folder);
                    emit(e);
                }
            } catch (Exception ignored) {
            } finally { prefetching.remove(key); }
        });
    }

    JSONObject body(String acc, String folder, long uid, boolean refresh) throws Exception {
        JSONObject b = refresh ? null : db.body(acc, folder, uid);
        if (b != null && b.has("html")) return b;
        b = eng.body(acc(acc), folder, uid);
        db.putBody(acc, folder, uid, b);
        JSONArray from = b.optJSONObject("hdr") == null ? null : b.optJSONObject("hdr").optJSONArray("from");
        if (from != null && from.length() > 0 && !"spam".equals(db.roleOf(acc, folder))) db.addContact(from.optJSONObject(0).optString("a"), from.optJSONObject(0).optString("n"), 0);
        return b;
    }

    static long[] uids(JSONArray a) {
        long[] r = new long[a == null ? 0 : a.length()];
        for (int i = 0; i < r.length; i++) r[i] = a.optLong(i);
        return r;
    }

    Object flag(JSONObject a) throws Exception {
        String acc = a.getString("acc"), folder = a.getString("folder"), flag = a.getString("flag");
        boolean v = a.optBoolean("value");
        long[] us = uids(a.optJSONArray("uids"));
        db.setFlag(acc, folder, us, flag, v);
        try { eng.flags(acc(acc), folder, us, flag, v); }
        catch (Exception e) { db.setFlag(acc, folder, us, flag, !v); throw e; }
        return true;
    }

    Object move(JSONObject a) throws Exception {
        String acc = a.getString("acc"), folder = a.getString("folder");
        String to = target(acc, a.getString("target"));
        long[] us = uids(a.optJSONArray("uids"));
        if (to.equals(folder)) return to;
        List<JSONObject> keep = new ArrayList<>();
        for (long u : us) { JSONObject r = db.row(acc, folder, u); if (r != null) keep.add(r); }
        db.remove(acc, folder, us);
        try { eng.move(acc(acc), folder, us, to); }
        catch (Exception e) { restore(acc, folder, keep); throw e; }
        return to;
    }

    void restore(String acc, String folder, List<JSONObject> rows) {
        JSONArray arr = new JSONArray();
        for (JSONObject r : rows) arr.put(r);
        db.insertRows(acc, folder, arr);
    }

    Object remove(JSONObject a) throws Exception {
        String acc = a.getString("acc"), folder = a.getString("folder");
        String role = db.roleOf(acc, folder);
        long[] us = uids(a.optJSONArray("uids"));
        JSONObject r = new JSONObject();
        if (role.equals("trash") || a.optBoolean("forever")) {
            List<JSONObject> keep = new ArrayList<>();
            for (long u : us) { JSONObject x = db.row(acc, folder, u); if (x != null) keep.add(x); }
            db.remove(acc, folder, us);
            try { eng.destroy(acc(acc), folder, us); } catch (Exception e) { restore(acc, folder, keep); throw e; }
            r.put("destroyed", true);
        } else {
            a.put("target", "@trash");
            r.put("to", move(a));
            r.put("destroyed", false);
        }
        return r;
    }

    /* ======================= compose ======================= */
    MimeMessage build(MailEngine.Acc A, JSONObject msg) throws Exception {
        List<File> files = new ArrayList<>();
        List<String> names = new ArrayList<>();
        JSONArray fa = msg.optJSONArray("files");
        if (fa != null) for (int i = 0; i < fa.length(); i++) {
            JSONObject f = fa.optJSONObject(i);
            File x = new File(f.optString("path"));
            if (!x.exists()) throw new MailEngine.MailError("Вложение «" + f.optString("name") + "» не найдено — прикрепите его заново", null);
            files.add(x);
            names.add(f.optString("name", x.getName()));
        }
        return eng.build(A, msg, files, names);
    }

    JSONObject send(JSONObject a) throws Exception {
        String id;
        synchronized (this) { id = "s" + System.currentTimeMillis() + "_" + (++seq); }
        long delay = Math.max(0, Math.min(30000, a.optLong("delay", 0)));
        // validate now so obvious mistakes are reported before the undo window
        MailEngine.parseAddrs(a.getJSONObject("msg").optString("to"));
        MailEngine.parseAddrs(a.getJSONObject("msg").optString("cc"));
        MailEngine.parseAddrs(a.getJSONObject("msg").optString("bcc"));
        pendingSends.add(id);
        sched.schedule(() -> { if (pendingSends.remove(id)) net.execute(() -> doSend(id, a)); }, delay, TimeUnit.MILLISECONDS);
        JSONObject r = new JSONObject();
        r.put("sendId", id);
        return r;
    }

    boolean cancelSend(String id) { return pendingSends.remove(id); }

    void doSend(String id, JSONObject a) {
        JSONObject e = ev("sent");
        String acc = a.optString("acc");
        JSONObject msg = a.optJSONObject("msg");
        try {
            e.put("sendId", id);
            e.put("subject", msg.optString("subject"));
            MailEngine.Acc A = acc(acc);
            MimeMessage m = build(A, msg);
            String sent = null;
            try { sent = target(acc, "@sent"); } catch (Exception ignored) { }
            JSONObject r = eng.send(A, m, sent);
            e.put("ok", true);
            e.put("copied", r.optBoolean("copied"));
            JSONObject an = a.optJSONObject("answer");
            if (an != null) try {
                long[] u = {an.optLong("uid")};
                db.setFlag(an.optString("acc", acc), an.optString("folder"), u, "answered", true);
                eng.flags(acc(an.optString("acc", acc)), an.optString("folder"), u, "answered", true);
            } catch (Exception ignored) { }
            long du = a.optLong("draftUid", 0);
            if (du > 0) try {
                String dr = target(acc, "@drafts");
                db.remove(acc, dr, new long[]{du});
                eng.destroy(A, dr, new long[]{du});
            } catch (Exception ignored) { }
            try {
                for (String k : new String[]{"to", "cc", "bcc"})
                    for (InternetAddress ia : MailEngine.parseAddrs(msg.optString(k))) db.addContact(ia.getAddress(), ia.getPersonal(), 3);
            } catch (Exception ignored) { }
            cleanupFiles(msg);
            if (sent != null) { final String sf = sent; bg.execute(() -> { try { syncOne(acc, sf); JSONObject c = ev("changed"); c.put("acc", acc); c.put("folder", sf); emit(c); } catch (Exception ignored) { } }); }
        } catch (Exception ex) {
            try {
                e.put("ok", false);
                e.put("error", ex.getMessage() == null ? ex.toString() : ex.getMessage());
                try {
                    long du = saveDraftInternal(acc, msg, a.optLong("draftUid", 0));
                    e.put("draftUid", du);
                    e.put("savedDraft", true);
                } catch (Exception ignored) { e.put("savedDraft", false); }
                e.put("req", a);
            } catch (Exception ignored) { }
            if (!foreground()) Notifier.sendFailed(ctx, msg.optString("subject"), e.optString("error"));
        }
        emit(e);
    }

    void cleanupFiles(JSONObject msg) {
        JSONArray fa = msg.optJSONArray("files");
        if (fa == null) return;
        String out = new File(ctx.getCacheDir(), "out").getAbsolutePath();
        for (int i = 0; i < fa.length(); i++) {
            File f = new File(fa.optJSONObject(i).optString("path"));
            if (f.getAbsolutePath().startsWith(out)) { f.delete(); File p = f.getParentFile(); if (p != null) { String[] l = p.list(); if (l != null && l.length == 0) p.delete(); } }
        }
    }

    long saveDraftInternal(String acc, JSONObject msg, long oldUid) throws Exception {
        MailEngine.Acc A = acc(acc);
        String dr = target(acc, "@drafts");
        long uid = eng.append(A, dr, build(A, msg), true, true);
        if (oldUid > 0) try { eng.destroy(A, dr, new long[]{oldUid}); db.remove(acc, dr, new long[]{oldUid}); } catch (Exception ignored) { }
        try { syncOne(acc, dr); } catch (Exception ignored) { }
        return uid;
    }

    JSONObject saveDraft(JSONObject a) throws Exception {
        JSONObject r = new JSONObject();
        r.put("uid", saveDraftInternal(a.getString("acc"), a.getJSONObject("msg"), a.optLong("draftUid", 0)));
        return r;
    }

    /* ======================= attachments ======================= */
    static String hash(String s) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-1").digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 10; i++) sb.append(String.format("%02x", d[i]));
            return sb.toString();
        } catch (Exception e) { return String.valueOf(s.hashCode()); }
    }

    static String safeName(String n) {
        if (n == null || n.trim().isEmpty()) n = "file";
        n = n.replaceAll("[\\\\/:*?\"<>|\\x00-\\x1f]", "_").trim();
        if (n.startsWith(".")) n = "_" + n;
        return n.length() > 120 ? n.substring(n.length() - 120) : n;
    }

    final Map<String, java.util.concurrent.Semaphore> attLocks = new ConcurrentHashMap<>();

    /** downloads are cached; at most two run at once per account so servers don't refuse extra connections */
    File attFile(String acc, String folder, long uid, String part, String name) throws Exception {
        File dir = new File(ctx.getCacheDir(), "att/" + hash(acc + "|" + folder + "|" + uid + "|" + part));
        File f = new File(dir, safeName(name));
        if (f.exists() && f.length() > 0) return f;
        java.util.concurrent.Semaphore sem = attLocks.computeIfAbsent(acc, k -> new java.util.concurrent.Semaphore(2));
        sem.acquireUninterruptibly();
        try {
            if (f.exists() && f.length() > 0) return f;
            return eng.savePart(acc(acc), folder, uid, part, f);
        } finally { sem.release(); }
    }

    File cidFile(String acc, String folder, long uid, String cid) throws Exception {
        return attFile(acc, folder, uid, "cid:" + cid, "cid.bin");
    }

    JSONArray fwdAtts(JSONObject a) throws Exception {
        String acc = a.getString("acc"), folder = a.getString("folder");
        long uid = a.getLong("uid");
        JSONObject b = body(acc, folder, uid, false);
        JSONArray atts = b.optJSONArray("atts"), out = new JSONArray();
        boolean all = a.optBoolean("includeInline");
        File dir = new File(ctx.getCacheDir(), "out/" + System.currentTimeMillis());
        if (atts != null) for (int i = 0; i < atts.length(); i++) {
            JSONObject x = atts.optJSONObject(i);
            if (x.optBoolean("inline") && !all) continue;
            File f = eng.savePart(acc(acc), folder, uid, x.optString("p"), uniq(dir, safeName(x.optString("name"))));
            JSONObject o = new JSONObject();
            o.put("path", f.getAbsolutePath()); o.put("name", x.optString("name")); o.put("size", f.length()); o.put("mime", x.optString("mime"));
            out.put(o);
        }
        return out;
    }

    static File uniq(File dir, String name) {
        dir.mkdirs();
        File f = new File(dir, name);
        int i = 1;
        while (f.exists()) {
            int dot = name.lastIndexOf('.');
            f = new File(dir, dot > 0 ? name.substring(0, dot) + " (" + i + ")" + name.substring(dot) : name + " (" + i + ")");
            i++;
        }
        return f;
    }

    /* ======================= dispatcher ======================= */
    Object call(String m, JSONObject a, Host host) throws Exception {
        switch (m) {
            case "addAccount": return addAccount(a);
            case "updateAccount": return updateAccount(a);
            case "removeAccount": removeAccount(a.getString("id")); return true;
            case "folders": return folders(a.getString("acc"), a.optBoolean("refresh"));
            case "list": {
                String acc = a.getString("acc");
                int off = a.optInt("offset"), lim = a.optInt("limit", 60);
                if ("*".equals(acc)) return db.listUnified("inbox", off, lim, a.optString("filter"));
                return db.list(acc, a.getString("folder"), off, lim, a.optString("filter"));
            }
            case "sync": return sync(a.getString("acc"), a.optString("folder"));
            case "more": return more(a.getString("acc"), a.getString("folder"));
            case "body": return body(a.getString("acc"), a.getString("folder"), a.getLong("uid"), a.optBoolean("refresh"));
            case "flag": return flag(a);
            case "move": return move(a);
            case "remove": return remove(a);
            case "emptyFolder": {
                String acc = a.getString("acc"), f = a.getString("folder");
                eng.emptyFolder(acc(acc), f);
                db.clearFolder(acc, f);
                return true;
            }
            case "markAllRead": {
                String acc = a.getString("acc"), f = a.getString("folder");
                eng.markAllRead(acc(acc), f);
                db.markAllRead(acc, f);
                return true;
            }
            case "createFolder": {
                String acc = a.getString("acc");
                eng.createFolder(acc(acc), a.getString("name"));
                return folders(acc, true);
            }
            case "deleteFolder": {
                String acc = a.getString("acc");
                eng.deleteFolder(acc(acc), a.getString("name"));
                return folders(acc, true);
            }
            case "send": return send(a);
            case "saveDraft": return saveDraft(a);
            case "deleteDraft": {
                String acc = a.getString("acc"), dr = target(acc, "@drafts");
                long[] u = {a.getLong("uid")};
                db.remove(acc, dr, u);
                eng.destroy(acc(acc), dr, u);
                return true;
            }
            case "search": {
                String acc = a.getString("acc"), f = a.getString("folder");
                JSONArray rows = eng.search(acc(acc), f, a.getString("q"), 100);
                for (int i = 0; i < rows.length(); i++) { JSONObject r = rows.getJSONObject(i); r.put("acc", acc); r.put("folder", f); JSONObject c = db.row(acc, f, r.optLong("uid")); if (c != null) r.put("snippet", c.opt("snippet")); }
                return rows;
            }
            case "localSearch": return db.localSearch(a.getString("q"), a.optString("acc"), 200);
            case "contacts": return db.contacts(a.optString("q"), 8);
            case "attOpen": case "attShare": case "attSave": case "attFile": {
                File f = attFile(a.getString("acc"), a.getString("folder"), a.getLong("uid"), a.getString("p"), a.optString("name"));
                String mime = a.optString("mime", "application/octet-stream");
                if (m.equals("attOpen")) host.openFile(f, mime);
                else if (m.equals("attShare")) host.shareFile(f, mime);
                else if (m.equals("attSave")) return host.saveDownload(f, a.optString("name", f.getName()), mime);
                return f.getAbsolutePath();
            }
            case "fwdAtts": return fwdAtts(a);
            case "source": return eng.source(acc(a.getString("acc")), a.getString("folder"), a.getLong("uid"), 1024 * 1024);
            case "unreadCounts": {
                JSONObject r = new JSONObject();
                JSONArray all = accounts();
                for (int i = 0; i < all.length(); i++) {
                    String id = all.optJSONObject(i).optString("id");
                    String inbox = db.folderByRole(id, "inbox");
                    int n = 0;
                    if (inbox != null) { JSONArray fs = db.folders(id); for (int j = 0; j < fs.length(); j++) if (fs.optJSONObject(j).optString("name").equals(inbox)) n = fs.optJSONObject(j).optInt("unread"); }
                    r.put(id, n);
                }
                return r;
            }
            default: throw new MailEngine.MailError("Неизвестная команда: " + m, null);
        }
    }

    /* ======================= background check ======================= */
    /** called by the periodic job: sync every INBOX and notify about fresh unread mail */
    void checkNew() {
        JSONArray all = accounts();
        for (int i = 0; i < all.length(); i++) {
            JSONObject a = all.optJSONObject(i);
            String id = a.optString("id");
            try {
                String inbox = target(id, "@inbox");
                long last = prefs().getLong("nl_" + id, -1);
                JSONObject r = syncOne(id, inbox);
                long max = db.folderState(id, inbox)[1];
                List<JSONObject> fresh = new ArrayList<>();
                JSONArray rows = r.optJSONArray("rows");
                if (last >= 0 && !r.optBoolean("first") && rows != null)
                    for (int k = 0; k < rows.length(); k++) {
                        JSONObject x = rows.optJSONObject(k);
                        if (x.optLong("uid") > last && x.optInt("seen") == 0) fresh.add(x);
                    }
                prefs().edit().putLong("nl_" + id, Math.max(last, max)).apply();
                if (r.optInt("added") > 0) { JSONObject c = ev("changed"); c.put("acc", id); c.put("folder", inbox); emit(c); }
                if (fresh.isEmpty() || !a.optBoolean("notify", true) || foreground()) continue;
                Collections.sort(fresh, (x, y) -> Long.compare(y.optLong("date"), x.optLong("date")));
                if (fresh.size() > 6) fresh = fresh.subList(0, 6);
                long[] us = new long[fresh.size()];
                for (int k = 0; k < us.length; k++) us[k] = fresh.get(k).optLong("uid");
                try {
                    JSONArray bs = eng.bodies(acc(id), inbox, us);
                    for (int k = 0; k < bs.length(); k++) {
                        JSONObject b = bs.optJSONObject(k);
                        if (b.optBoolean("failed")) continue;
                        db.putBody(id, inbox, b.optLong("uid"), b);
                        for (JSONObject x : fresh) if (x.optLong("uid") == b.optLong("uid")) x.put("snippet", b.optString("snippet"));
                    }
                } catch (Exception ignored) { }
                Notifier.newMail(ctx, a, inbox, fresh, all.length() > 1);
            } catch (Exception ignored) { }
        }
    }
}
