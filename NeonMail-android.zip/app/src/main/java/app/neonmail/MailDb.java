package app.neonmail;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Local cache: folders, message headers, bodies and an address book for autocomplete. */
final class MailDb extends SQLiteOpenHelper {
    static final String COLS = "acc,folder,uid,msgid,fromName,fromAddr,toList,cc,subject,date,seen,flagged,answered,draft,size,att,snippet";

    MailDb(Context c) { super(c, "mail.db", null, 1); }

    @Override
    public void onCreate(SQLiteDatabase d) {
        d.execSQL("CREATE TABLE folder(acc TEXT, name TEXT, role TEXT, sep TEXT, noselect INTEGER, unread INTEGER DEFAULT 0, total INTEGER DEFAULT 0, validity INTEGER DEFAULT 0, maxuid INTEGER DEFAULT 0, PRIMARY KEY(acc,name))");
        d.execSQL("CREATE TABLE msg(acc TEXT, folder TEXT, uid INTEGER, msgid TEXT, fromName TEXT, fromAddr TEXT, toList TEXT, cc TEXT, subject TEXT, date INTEGER, seen INTEGER, flagged INTEGER, answered INTEGER, draft INTEGER, size INTEGER, att INTEGER, snippet TEXT, PRIMARY KEY(acc,folder,uid))");
        d.execSQL("CREATE INDEX msg_date ON msg(acc,folder,date DESC)");
        d.execSQL("CREATE INDEX msg_all_date ON msg(date DESC)");
        d.execSQL("CREATE TABLE body(acc TEXT, folder TEXT, uid INTEGER, json TEXT, ts INTEGER, PRIMARY KEY(acc,folder,uid))");
        d.execSQL("CREATE TABLE contact(addr TEXT PRIMARY KEY, name TEXT, cnt INTEGER DEFAULT 0, last INTEGER DEFAULT 0)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase d, int o, int n) { }

    /* ---------------- folders ---------------- */
    static int roleRank(String r) {
        switch (r == null ? "" : r) {
            case "inbox": return 0;
            case "flagged": return 1;
            case "important": return 2;
            case "drafts": return 3;
            case "sent": return 4;
            case "archive": return 5;
            case "all": return 6;
            case "spam": return 7;
            case "trash": return 8;
            default: return 20;
        }
    }

    synchronized void upsertFolders(String acc, JSONArray fs) {
        SQLiteDatabase d = getWritableDatabase();
        d.beginTransaction();
        try {
            Set<String> keep = new HashSet<>();
            for (int i = 0; i < fs.length(); i++) {
                JSONObject f = fs.optJSONObject(i);
                if (f == null) continue;
                String name = f.optString("name");
                keep.add(name);
                ContentValues v = new ContentValues();
                v.put("role", f.optString("role"));
                v.put("sep", f.optString("sep", "/"));
                v.put("noselect", f.optBoolean("noselect") ? 1 : 0);
                if (f.has("unread")) v.put("unread", f.optInt("unread"));
                if (f.has("total")) v.put("total", f.optInt("total"));
                if (d.update("folder", v, "acc=? AND name=?", new String[]{acc, name}) == 0) {
                    v.put("acc", acc); v.put("name", name);
                    d.insert("folder", null, v);
                }
            }
            Cursor c = d.rawQuery("SELECT name FROM folder WHERE acc=?", new String[]{acc});
            List<String> drop = new ArrayList<>();
            while (c.moveToNext()) if (!keep.contains(c.getString(0))) drop.add(c.getString(0));
            c.close();
            for (String n : drop) {
                d.delete("folder", "acc=? AND name=?", new String[]{acc, n});
                d.delete("msg", "acc=? AND folder=?", new String[]{acc, n});
                d.delete("body", "acc=? AND folder=?", new String[]{acc, n});
            }
            d.setTransactionSuccessful();
        } finally { d.endTransaction(); }
    }

    synchronized JSONArray folders(String acc) {
        JSONArray out = new JSONArray();
        Cursor c = getReadableDatabase().rawQuery("SELECT name,role,sep,noselect,unread,total,(SELECT COUNT(*) FROM msg m WHERE m.acc=f.acc AND m.folder=f.name) FROM folder f WHERE acc=?", new String[]{acc});
        List<JSONObject> l = new ArrayList<>();
        while (c.moveToNext()) {
            JSONObject o = new JSONObject();
            try {
                o.put("acc", acc); o.put("name", c.getString(0)); o.put("role", c.getString(1)); o.put("sep", c.getString(2));
                o.put("noselect", c.getInt(3) == 1); o.put("unread", c.getInt(4)); o.put("total", c.getInt(5)); o.put("cached", c.getInt(6));
            } catch (Exception ignored) { }
            l.add(o);
        }
        c.close();
        l.sort((a, b) -> {
            int ra = roleRank(a.optString("role")), rb = roleRank(b.optString("role"));
            if (ra != rb) return ra - rb;
            return a.optString("name").toLowerCase(Locale.ROOT).compareTo(b.optString("name").toLowerCase(Locale.ROOT));
        });
        for (JSONObject o : l) out.put(o);
        return out;
    }

    synchronized String folderByRole(String acc, String role) {
        Cursor c = getReadableDatabase().rawQuery("SELECT name FROM folder WHERE acc=? AND role=? AND noselect=0 LIMIT 1", new String[]{acc, role});
        String r = c.moveToFirst() ? c.getString(0) : null;
        c.close();
        return r;
    }

    synchronized String roleOf(String acc, String folder) {
        Cursor c = getReadableDatabase().rawQuery("SELECT role FROM folder WHERE acc=? AND name=?", new String[]{acc, folder});
        String r = c.moveToFirst() ? c.getString(0) : "";
        c.close();
        return r == null ? "" : r;
    }

    synchronized long[] folderState(String acc, String folder) {
        Cursor c = getReadableDatabase().rawQuery("SELECT validity,maxuid FROM folder WHERE acc=? AND name=?", new String[]{acc, folder});
        long[] r = c.moveToFirst() ? new long[]{c.getLong(0), c.getLong(1)} : new long[]{0, 0};
        c.close();
        return r;
    }

    synchronized long[] window(String acc, String folder, int n) {
        Cursor c = getReadableDatabase().rawQuery("SELECT uid FROM msg WHERE acc=? AND folder=? ORDER BY uid DESC LIMIT " + n, new String[]{acc, folder});
        long[] r = new long[c.getCount()];
        int i = 0;
        while (c.moveToNext()) r[i++] = c.getLong(0);
        c.close();
        return r;
    }

    synchronized long minUid(String acc, String folder) {
        Cursor c = getReadableDatabase().rawQuery("SELECT MIN(uid) FROM msg WHERE acc=? AND folder=?", new String[]{acc, folder});
        long r = c.moveToFirst() && !c.isNull(0) ? c.getLong(0) : 0;
        c.close();
        return r;
    }

    synchronized int count(String acc, String folder) {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM msg WHERE acc=? AND folder=?", new String[]{acc, folder});
        int r = c.moveToFirst() ? c.getInt(0) : 0;
        c.close();
        return r;
    }

    /* ---------------- messages ---------------- */
    static ContentValues rowValues(String acc, String folder, JSONObject r) {
        ContentValues v = new ContentValues();
        v.put("acc", acc); v.put("folder", folder); v.put("uid", r.optLong("uid"));
        v.put("msgid", r.optString("msgid")); v.put("fromName", r.optString("fromName")); v.put("fromAddr", r.optString("fromAddr"));
        v.put("toList", r.optString("to")); v.put("cc", r.optString("cc")); v.put("subject", r.optString("subject"));
        v.put("date", r.optLong("date")); v.put("seen", r.optInt("seen")); v.put("flagged", r.optInt("flagged"));
        v.put("answered", r.optInt("answered")); v.put("draft", r.optInt("draft")); v.put("size", r.optLong("size")); v.put("att", r.optInt("att"));
        return v;
    }

    /** apply MailEngine.sync() output; returns the number of new rows */
    synchronized int applySync(String acc, String folder, JSONObject r) {
        SQLiteDatabase d = getWritableDatabase();
        int added = 0;
        d.beginTransaction();
        try {
            String[] af = {acc, folder};
            if (r.optBoolean("reset")) { d.delete("msg", "acc=? AND folder=?", af); d.delete("body", "acc=? AND folder=?", af); }
            JSONArray rows = r.optJSONArray("rows");
            long max = 0;
            if (rows != null) for (int i = 0; i < rows.length(); i++) {
                JSONObject o = rows.optJSONObject(i);
                if (o == null || o.optLong("uid") <= 0) continue;
                max = Math.max(max, o.optLong("uid"));
                if (d.insertWithOnConflict("msg", null, rowValues(acc, folder, o), SQLiteDatabase.CONFLICT_IGNORE) != -1) added++;
            }
            JSONArray fl = r.optJSONArray("flags");
            if (fl != null) for (int i = 0; i < fl.length(); i++) {
                JSONArray x = fl.optJSONArray(i);
                if (x == null) continue;
                ContentValues v = new ContentValues();
                v.put("seen", x.optInt(1)); v.put("flagged", x.optInt(2)); v.put("answered", x.optInt(3));
                d.update("msg", v, "acc=? AND folder=? AND uid=?", new String[]{acc, folder, String.valueOf(x.optLong(0))});
            }
            JSONArray gone = r.optJSONArray("gone");
            if (gone != null) for (int i = 0; i < gone.length(); i++) {
                String[] k = {acc, folder, String.valueOf(gone.optLong(i))};
                d.delete("msg", "acc=? AND folder=? AND uid=?", k);
                d.delete("body", "acc=? AND folder=? AND uid=?", k);
            }
            ContentValues fv = new ContentValues();
            fv.put("validity", r.optLong("uidvalidity"));
            fv.put("unread", r.optInt("unread"));
            fv.put("total", r.optInt("total"));
            long[] st = folderState(acc, folder);
            fv.put("maxuid", r.optBoolean("reset") ? max : Math.max(st[1], max));
            if (d.update("folder", fv, "acc=? AND name=?", af) == 0) {
                fv.put("acc", acc); fv.put("name", folder); fv.put("role", ""); fv.put("sep", "/"); fv.put("noselect", 0);
                d.insert("folder", null, fv);
            }
            d.setTransactionSuccessful();
        } finally { d.endTransaction(); }
        return added;
    }

    synchronized int insertRows(String acc, String folder, JSONArray rows) {
        SQLiteDatabase d = getWritableDatabase();
        int n = 0;
        d.beginTransaction();
        try {
            for (int i = 0; i < rows.length(); i++) {
                JSONObject o = rows.optJSONObject(i);
                if (o != null && o.optLong("uid") > 0 && d.insertWithOnConflict("msg", null, rowValues(acc, folder, o), SQLiteDatabase.CONFLICT_IGNORE) != -1) n++;
            }
            d.setTransactionSuccessful();
        } finally { d.endTransaction(); }
        return n;
    }

    static JSONObject rowJson(Cursor c) {
        JSONObject o = new JSONObject();
        try {
            o.put("acc", c.getString(0)); o.put("folder", c.getString(1)); o.put("uid", c.getLong(2)); o.put("msgid", c.getString(3));
            o.put("fromName", c.getString(4)); o.put("fromAddr", c.getString(5)); o.put("to", c.getString(6)); o.put("cc", c.getString(7));
            o.put("subject", c.getString(8)); o.put("date", c.getLong(9)); o.put("seen", c.getInt(10)); o.put("flagged", c.getInt(11));
            o.put("answered", c.getInt(12)); o.put("draft", c.getInt(13)); o.put("size", c.getLong(14)); o.put("att", c.getInt(15));
            o.put("snippet", c.isNull(16) ? null : c.getString(16));
        } catch (Exception ignored) { }
        return o;
    }

    static String filterSql(String filter) {
        switch (filter == null ? "" : filter) {
            case "unread": return " AND m.seen=0";
            case "flagged": return " AND m.flagged=1";
            case "att": return " AND m.att=1";
            default: return "";
        }
    }

    synchronized JSONArray list(String acc, String folder, int offset, int limit, String filter) {
        String sql = "SELECT " + prefixed() + " FROM msg m WHERE m.acc=? AND m.folder=?" + filterSql(filter) + " ORDER BY m.date DESC, m.uid DESC LIMIT " + limit + " OFFSET " + offset;
        return query(sql, new String[]{acc, folder});
    }

    /** unified inbox of all accounts */
    synchronized JSONArray listUnified(String role, int offset, int limit, String filter) {
        String sql = "SELECT " + prefixed() + " FROM msg m JOIN folder f ON f.acc=m.acc AND f.name=m.folder WHERE f.role=?" + filterSql(filter) + " ORDER BY m.date DESC, m.uid DESC LIMIT " + limit + " OFFSET " + offset;
        return query(sql, new String[]{role});
    }

    synchronized JSONArray localSearch(String q, String acc, int limit) {
        List<String> args = new ArrayList<>();
        StringBuilder w = new StringBuilder("1=1");
        if (acc != null && !acc.isEmpty() && !"*".equals(acc)) { w.append(" AND m.acc=?"); args.add(acc); }
        for (String t : q.trim().split("\\s+")) {
            if (t.isEmpty()) continue;
            String like = "%" + t.replace("%", "").replace("_", "") + "%";
            w.append(" AND (m.subject LIKE ? OR m.fromName LIKE ? OR m.fromAddr LIKE ? OR m.toList LIKE ? OR m.snippet LIKE ?)");
            for (int i = 0; i < 5; i++) args.add(like);
        }
        String sql = "SELECT " + prefixed() + " FROM msg m WHERE " + w + " ORDER BY m.date DESC LIMIT " + limit;
        JSONArray r = query(sql, args.toArray(new String[0]));
        // SQLite LIKE is case-insensitive only for ASCII: repeat for Cyrillic in Java
        if (hasNonAscii(q)) r = javaFilter(q, acc, limit, r);
        return r;
    }

    static boolean hasNonAscii(String s) { for (int i = 0; i < s.length(); i++) if (s.charAt(i) > 127) return true; return false; }

    JSONArray javaFilter(String q, String acc, int limit, JSONArray already) {
        Set<String> seen = new HashSet<>();
        JSONArray out = new JSONArray();
        for (int i = 0; i < already.length(); i++) { JSONObject o = already.optJSONObject(i); out.put(o); seen.add(o.optString("acc") + "|" + o.optString("folder") + "|" + o.optLong("uid")); }
        String[] terms = q.toLowerCase(Locale.ROOT).trim().split("\\s+");
        String sql = "SELECT " + prefixed() + " FROM msg m" + (acc != null && !acc.isEmpty() && !"*".equals(acc) ? " WHERE m.acc=?" : "") + " ORDER BY m.date DESC LIMIT 5000";
        Cursor c = getReadableDatabase().rawQuery(sql, acc != null && !acc.isEmpty() && !"*".equals(acc) ? new String[]{acc} : null);
        while (c.moveToNext() && out.length() < limit) {
            String hay = (s(c, 8) + " " + s(c, 4) + " " + s(c, 5) + " " + s(c, 6) + " " + s(c, 16)).toLowerCase(Locale.ROOT);
            boolean ok = true;
            for (String t : terms) if (!t.isEmpty() && !hay.contains(t)) { ok = false; break; }
            if (!ok) continue;
            JSONObject o = rowJson(c);
            if (seen.add(o.optString("acc") + "|" + o.optString("folder") + "|" + o.optLong("uid"))) out.put(o);
        }
        c.close();
        return out;
    }

    static String s(Cursor c, int i) { return c.isNull(i) ? "" : c.getString(i); }

    static String prefixed() {
        StringBuilder sb = new StringBuilder();
        for (String x : COLS.split(",")) { if (sb.length() > 0) sb.append(','); sb.append("m.").append(x); }
        return sb.toString();
    }

    JSONArray query(String sql, String[] args) {
        JSONArray out = new JSONArray();
        Cursor c = getReadableDatabase().rawQuery(sql, args);
        while (c.moveToNext()) out.put(rowJson(c));
        c.close();
        return out;
    }

    synchronized JSONObject row(String acc, String folder, long uid) {
        JSONArray r = query("SELECT " + prefixed() + " FROM msg m WHERE m.acc=? AND m.folder=? AND m.uid=?", new String[]{acc, folder, String.valueOf(uid)});
        return r.length() > 0 ? r.optJSONObject(0) : null;
    }

    /** local flag change; keeps the folder's unread counter right */
    synchronized void setFlag(String acc, String folder, long[] uids, String col, boolean val) {
        if (!col.equals("seen") && !col.equals("flagged") && !col.equals("answered")) return;
        SQLiteDatabase d = getWritableDatabase();
        d.beginTransaction();
        try {
            int changed = 0;
            for (long u : uids) {
                ContentValues v = new ContentValues();
                v.put(col, val ? 1 : 0);
                changed += d.update("msg", v, "acc=? AND folder=? AND uid=? AND " + col + "<>?", new String[]{acc, folder, String.valueOf(u), val ? "1" : "0"});
            }
            if (col.equals("seen") && changed > 0)
                d.execSQL("UPDATE folder SET unread=MAX(0, unread" + (val ? "-" : "+") + changed + ") WHERE acc=? AND name=?", new Object[]{acc, folder});
            d.setTransactionSuccessful();
        } finally { d.endTransaction(); }
    }

    synchronized void markAllRead(String acc, String folder) {
        getWritableDatabase().execSQL("UPDATE msg SET seen=1 WHERE acc=? AND folder=?", new Object[]{acc, folder});
        getWritableDatabase().execSQL("UPDATE folder SET unread=0 WHERE acc=? AND name=?", new Object[]{acc, folder});
    }

    synchronized void remove(String acc, String folder, long[] uids) {
        SQLiteDatabase d = getWritableDatabase();
        d.beginTransaction();
        try {
            int unseen = 0;
            for (long u : uids) {
                String[] k = {acc, folder, String.valueOf(u)};
                Cursor c = d.rawQuery("SELECT seen FROM msg WHERE acc=? AND folder=? AND uid=?", k);
                if (c.moveToFirst() && c.getInt(0) == 0) unseen++;
                c.close();
                d.delete("msg", "acc=? AND folder=? AND uid=?", k);
                d.delete("body", "acc=? AND folder=? AND uid=?", k);
            }
            if (unseen > 0) d.execSQL("UPDATE folder SET unread=MAX(0, unread-" + unseen + "), total=MAX(0, total-" + uids.length + ") WHERE acc=? AND name=?", new Object[]{acc, folder});
            else d.execSQL("UPDATE folder SET total=MAX(0, total-" + uids.length + ") WHERE acc=? AND name=?", new Object[]{acc, folder});
            d.setTransactionSuccessful();
        } finally { d.endTransaction(); }
    }

    synchronized void clearFolder(String acc, String folder) {
        getWritableDatabase().delete("msg", "acc=? AND folder=?", new String[]{acc, folder});
        getWritableDatabase().delete("body", "acc=? AND folder=?", new String[]{acc, folder});
        getWritableDatabase().execSQL("UPDATE folder SET unread=0, total=0 WHERE acc=? AND name=?", new Object[]{acc, folder});
    }

    synchronized void deleteAccount(String acc) {
        SQLiteDatabase d = getWritableDatabase();
        for (String t : new String[]{"folder", "msg", "body"}) d.delete(t, "acc=?", new String[]{acc});
    }

    /* ---------------- bodies ---------------- */
    synchronized JSONObject body(String acc, String folder, long uid) {
        Cursor c = getReadableDatabase().rawQuery("SELECT json FROM body WHERE acc=? AND folder=? AND uid=?", new String[]{acc, folder, String.valueOf(uid)});
        JSONObject r = null;
        if (c.moveToFirst()) try { r = new JSONObject(c.getString(0)); } catch (Exception ignored) { }
        c.close();
        return r;
    }

    synchronized void putBody(String acc, String folder, long uid, JSONObject b) {
        ContentValues v = new ContentValues();
        v.put("acc", acc); v.put("folder", folder); v.put("uid", uid); v.put("json", b.toString()); v.put("ts", System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("body", null, v, SQLiteDatabase.CONFLICT_REPLACE);
        ContentValues s = new ContentValues();
        s.put("snippet", b.optString("snippet"));
        getWritableDatabase().update("msg", s, "acc=? AND folder=? AND uid=?", new String[]{acc, folder, String.valueOf(uid)});
    }

    synchronized void putSnippetOnly(String acc, String folder, long uid, String snippet) {
        ContentValues s = new ContentValues();
        s.put("snippet", snippet);
        getWritableDatabase().update("msg", s, "acc=? AND folder=? AND uid=?", new String[]{acc, folder, String.valueOf(uid)});
    }

    synchronized boolean hasSnippet(String acc, String folder, long uid) {
        Cursor c = getReadableDatabase().rawQuery("SELECT snippet FROM msg WHERE acc=? AND folder=? AND uid=?", new String[]{acc, folder, String.valueOf(uid)});
        boolean r = !c.moveToFirst() || !c.isNull(0);
        c.close();
        return r;
    }

    /** uids of newest rows that still have no snippet */
    synchronized long[] needSnippets(String acc, String folder, int n) {
        Cursor c = getReadableDatabase().rawQuery("SELECT uid FROM msg WHERE acc=? AND folder=? AND snippet IS NULL AND size<2000000 ORDER BY date DESC LIMIT " + n, new String[]{acc, folder});
        long[] r = new long[c.getCount()];
        int i = 0;
        while (c.moveToNext()) r[i++] = c.getLong(0);
        c.close();
        return r;
    }

    synchronized void trimBodies(int keep) {
        getWritableDatabase().execSQL("DELETE FROM body WHERE ts < (SELECT ts FROM body ORDER BY ts DESC LIMIT 1 OFFSET " + keep + ")");
    }

    /* ---------------- contacts ---------------- */
    synchronized void addContact(String addr, String name, int weight) {
        if (addr == null || !addr.contains("@")) return;
        addr = addr.trim().toLowerCase(Locale.ROOT);
        SQLiteDatabase d = getWritableDatabase();
        Cursor c = d.rawQuery("SELECT name,cnt FROM contact WHERE addr=?", new String[]{addr});
        boolean has = c.moveToFirst();
        String old = has ? c.getString(0) : null;
        c.close();
        ContentValues v = new ContentValues();
        v.put("name", name != null && !name.trim().isEmpty() ? name.trim() : old == null ? "" : old);
        v.put("last", System.currentTimeMillis());
        if (has) {
            d.update("contact", v, "addr=?", new String[]{addr});
            if (weight > 0) d.execSQL("UPDATE contact SET cnt=cnt+? WHERE addr=?", new Object[]{weight, addr});
        } else {
            v.put("addr", addr); v.put("cnt", weight);
            d.insert("contact", null, v);
        }
    }

    synchronized JSONArray contacts(String q, int limit) {
        String like = "%" + q.trim().replace("%", "") + "%";
        JSONArray out = new JSONArray();
        Cursor c = getReadableDatabase().rawQuery("SELECT addr,name,cnt FROM contact WHERE addr LIKE ? OR name LIKE ? ORDER BY cnt DESC, last DESC LIMIT " + (limit * 3), new String[]{like, like});
        String lq = q.trim().toLowerCase(Locale.ROOT);
        while (c.moveToNext() && out.length() < limit) {
            JSONObject o = new JSONObject();
            try { o.put("a", c.getString(0)); o.put("n", c.getString(1)); } catch (Exception ignored) { }
            out.put(o);
        }
        c.close();
        if (out.length() == 0 && hasNonAscii(lq)) {
            c = getReadableDatabase().rawQuery("SELECT addr,name FROM contact ORDER BY cnt DESC, last DESC LIMIT 3000", null);
            while (c.moveToNext() && out.length() < limit) {
                String n = s(c, 1);
                if (!n.toLowerCase(Locale.ROOT).contains(lq)) continue;
                JSONObject o = new JSONObject();
                try { o.put("a", c.getString(0)); o.put("n", n); } catch (Exception ignored) { }
                out.put(o);
            }
            c.close();
        }
        return out;
    }
}
