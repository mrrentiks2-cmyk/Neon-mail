package app.neonmail;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;

/** Periodic check for new mail (Android decides the exact moment; minimum is 15 minutes). */
public class MailJob extends JobService {
    static final int ID = 7101;

    static void schedule(Context c) {
        try {
            SharedPreferences p = c.getSharedPreferences("mail", Context.MODE_PRIVATE);
            int min = 15;
            try { min = Integer.parseInt(p.getString("p_notifyEvery", "15")); } catch (Exception ignored) { }
            boolean hasAcc = p.getString("accounts", "[]").length() > 4;
            JobScheduler js = c.getSystemService(JobScheduler.class);
            if (min <= 0 || !hasAcc) { js.cancel(ID); return; }
            long ms = Math.max(15, min) * 60000L;
            JobInfo cur = js.getPendingJob(ID);
            if (cur != null && cur.getIntervalMillis() == ms) return;
            js.schedule(new JobInfo.Builder(ID, new ComponentName(c, MailJob.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPersisted(true)
                    .setPeriodic(ms)
                    .build());
        } catch (Exception ignored) { }
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        Thread t = new Thread(() -> {
            Thread.currentThread().setContextClassLoader(MailJob.class.getClassLoader());
            try { Core.get(getApplicationContext()).checkNew(); } catch (Throwable ignored) { }
            jobFinished(params, false);
        });
        t.start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) { return true; }
}
