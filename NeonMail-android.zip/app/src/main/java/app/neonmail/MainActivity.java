package app.neonmail;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.MailTo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity implements Core.Listener, Core.Host {
    static final String HOST = "appassets.androidplatform.net";
    static final String START = "https://" + HOST + "/assets/www/index.html";
    static final int REQ_PICK = 11, REQ_NOTIF = 12, REQ_STORAGE = 13;
    static final int BG = Color.parseColor("#08090f");

    WebView web;
    WebViewAssetLoader loader;
    Core core;
    final Handler ui = new Handler(Looper.getMainLooper());
    volatile boolean resumed;
    JSONObject pending;
    String pickReq;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        core = Core.get(this);
        core.listener = this;
        Window w = getWindow();
        w.setStatusBarColor(BG);
        w.setNavigationBarColor(BG);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        web = new WebView(this);
        web.setBackgroundColor(BG);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        // letters often contain http:// pictures
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        loader = new WebViewAssetLoader.Builder().setDomain(HOST).addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String p = u.getPath();
                try {
                    if ("/cid".equals(p)) {
                        File f = core.cidFile(u.getQueryParameter("a"), u.getQueryParameter("f"), Long.parseLong(u.getQueryParameter("u")), u.getQueryParameter("c"));
                        return serve(f, u.getQueryParameter("m"));
                    }
                    if ("/att".equals(p)) {
                        File f = core.attFile(u.getQueryParameter("a"), u.getQueryParameter("f"), Long.parseLong(u.getQueryParameter("u")), u.getQueryParameter("p"), u.getQueryParameter("n"));
                        return serve(f, u.getQueryParameter("m"));
                    }
                    if ("/file".equals(p)) {
                        File f = new File(u.getQueryParameter("p"));
                        if (!f.getCanonicalPath().startsWith(getCacheDir().getCanonicalPath())) return notFound();
                        return serve(f, u.getQueryParameter("m"));
                    }
                } catch (Throwable e) { return notFound(); }
                return loader.shouldInterceptRequest(u);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                openUrl(u.toString());
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "M");
        web.loadUrl(START);
        handleIntent(getIntent(), false);
        MailJob.schedule(this);
        core.bg.execute(() -> { try { core.db.trimBodies(400); cleanCache(); } catch (Exception ignored) { } });
    }

    WebResourceResponse serve(File f, String mime) throws Exception {
        if (mime == null || mime.isEmpty()) mime = guessMime(f.getName());
        WebResourceResponse r = new WebResourceResponse(mime, null, new FileInputStream(f));
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", "max-age=86400");
        h.put("Access-Control-Allow-Origin", "*");
        r.setResponseHeaders(h);
        return r;
    }

    static WebResourceResponse notFound() {
        WebResourceResponse r = new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
        r.setStatusCodeAndReasonPhrase(404, "Not Found");
        return r;
    }

    static String guessMime(String name) {
        int i = name.lastIndexOf('.');
        String m = i > 0 ? MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(i + 1).toLowerCase()) : null;
        return m == null ? "application/octet-stream" : m;
    }

    void cleanCache() {
        long old = System.currentTimeMillis() - 3L * 86400000L;
        for (String d : new String[]{"att", "out", "share"}) {
            File dir = new File(getCacheDir(), d);
            File[] l = dir.listFiles();
            if (l != null) for (File f : l) if (f.lastModified() < old) deleteTree(f);
        }
    }

    static void deleteTree(File f) {
        File[] l = f.listFiles();
        if (l != null) for (File x : l) deleteTree(x);
        f.delete();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent, true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        core.listener = this;
        try { getSystemService(NotificationManager.class).cancelAll(); } catch (Exception ignored) { }
        emit(Core.ev("resume"));
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        emit(Core.ev("pause"));
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__mBack && window.__mBack()) ? 1 : 0", r -> { if (!"1".equals(r)) moveTaskToBack(true); });
    }

    @Override
    protected void onDestroy() {
        if (core.listener == this) core.listener = null;
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    /* ================= Core.Listener ================= */
    @Override
    public void emit(JSONObject o) {
        final String js = "window.__mEvent && window.__mEvent(" + JSONObject.quote(o.toString()) + ")";
        ui.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    @Override
    public boolean isForeground() { return resumed; }

    void toast(String t) { ui.post(() -> Toast.makeText(this, t, Toast.LENGTH_LONG).show()); }

    /* ================= intents ================= */
    synchronized void setPending(JSONObject o, boolean notify) {
        pending = o;
        if (notify) emit(Core.ev("intent"));
    }

    void handleIntent(Intent i, boolean notify) {
        if (i == null) return;
        try {
            String act = i.getAction();
            if (i.hasExtra("open_acc")) {
                JSONObject o = Core.ev("open");
                o.put("acc", i.getStringExtra("open_acc"));
                o.put("folder", i.getStringExtra("open_folder"));
                o.put("uid", i.getLongExtra("open_uid", 0));
                setPending(o, notify);
                return;
            }
            Uri data = i.getData();
            if ((Intent.ACTION_SENDTO.equals(act) || Intent.ACTION_VIEW.equals(act)) && data != null && "mailto".equalsIgnoreCase(data.getScheme())) {
                setPending(mailto(data.toString()), notify);
                return;
            }
            if (Intent.ACTION_SEND.equals(act) || Intent.ACTION_SEND_MULTIPLE.equals(act)) {
                final JSONObject o = Core.ev("compose");
                o.put("to", join(i.getStringArrayExtra(Intent.EXTRA_EMAIL)));
                o.put("cc", join(i.getStringArrayExtra(Intent.EXTRA_CC)));
                o.put("bcc", join(i.getStringArrayExtra(Intent.EXTRA_BCC)));
                CharSequence subj = i.getCharSequenceExtra(Intent.EXTRA_SUBJECT), text = i.getCharSequenceExtra(Intent.EXTRA_TEXT);
                o.put("subject", subj == null ? "" : subj.toString());
                o.put("body", text == null ? "" : text.toString());
                final List<Uri> uris = new ArrayList<>();
                if (Intent.ACTION_SEND.equals(act)) {
                    Uri u = i.getParcelableExtra(Intent.EXTRA_STREAM);
                    if (u != null) uris.add(u);
                } else {
                    ArrayList<Uri> l = i.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                    if (l != null) uris.addAll(l);
                }
                if (uris.isEmpty() && i.getClipData() != null) {
                    ClipData cd = i.getClipData();
                    for (int k = 0; k < cd.getItemCount(); k++) if (cd.getItemAt(k).getUri() != null) uris.add(cd.getItemAt(k).getUri());
                }
                if (uris.isEmpty()) { o.put("files", new JSONArray()); setPending(o, notify); return; }
                core.net.execute(() -> {
                    try { o.put("files", copyIn(uris, "share")); } catch (Exception ignored) { }
                    setPending(o, true);
                });
            }
        } catch (Exception ignored) { }
    }

    static String join(String[] a) {
        if (a == null) return "";
        StringBuilder sb = new StringBuilder();
        for (String s : a) { if (s == null || s.trim().isEmpty()) continue; if (sb.length() > 0) sb.append(", "); sb.append(s.trim()); }
        return sb.toString();
    }

    static JSONObject mailto(String url) throws Exception {
        JSONObject o = Core.ev("compose");
        MailTo m = MailTo.parse(url);
        o.put("to", m.getTo() == null ? "" : m.getTo());
        o.put("cc", m.getCc() == null ? "" : m.getCc());
        String bcc = m.getHeaders() == null ? null : m.getHeaders().get("bcc");
        o.put("bcc", bcc == null ? "" : bcc);
        o.put("subject", m.getSubject() == null ? "" : m.getSubject());
        o.put("body", m.getBody() == null ? "" : m.getBody());
        o.put("files", new JSONArray());
        return o;
    }

    JSONArray copyIn(List<Uri> uris, String kind) {
        JSONArray out = new JSONArray();
        File dir = new File(getCacheDir(), (kind.equals("share") ? "out" : "out") + "/" + System.currentTimeMillis());
        for (Uri u : uris) {
            try {
                String name = null, mime = getContentResolver().getType(u);
                try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                    if (c != null && c.moveToFirst()) name = c.getString(0);
                } catch (Exception ignored) { }
                if (name == null) name = u.getLastPathSegment();
                if (name == null) name = "file";
                if (!name.contains(".") && mime != null) {
                    String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
                    if (ext != null) name = name + "." + ext;
                }
                File f = Core.uniq(dir, Core.safeName(name));
                try (InputStream in = getContentResolver().openInputStream(u); OutputStream os = new FileOutputStream(f)) {
                    byte[] b = new byte[65536];
                    int n;
                    while ((n = in.read(b)) > 0) os.write(b, 0, n);
                }
                JSONObject o = new JSONObject();
                o.put("path", f.getAbsolutePath());
                o.put("name", name);
                o.put("size", f.length());
                o.put("mime", mime == null ? guessMime(name) : mime);
                out.put(o);
            } catch (Exception e) { toast("Не удалось прочитать файл: " + e.getMessage()); }
        }
        return out;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK) return;
        final String id = pickReq;
        pickReq = null;
        final List<Uri> uris = new ArrayList<>();
        if (res == RESULT_OK && data != null) {
            if (data.getClipData() != null) for (int i = 0; i < data.getClipData().getItemCount(); i++) uris.add(data.getClipData().getItemAt(i).getUri());
            else if (data.getData() != null) uris.add(data.getData());
        }
        core.net.execute(() -> {
            JSONObject e = Core.ev("res");
            try { e.put("id", id); e.put("ok", true); e.put("data", copyIn(uris, "pick")); } catch (Exception ignored) { }
            emit(e);
        });
    }

    void openUrl(String url) {
        try {
            if (url.toLowerCase().startsWith("mailto:")) { setPending(mailto(url), true); return; }
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) { toast("Не удалось открыть ссылку"); }
    }

    /* ================= Core.Host ================= */
    Uri uriFor(File f) { return FileProvider.getUriForFile(this, getPackageName() + ".files", f); }

    @Override
    public void openFile(File f, String mime) {
        ui.post(() -> {
            try {
                Uri u = uriFor(f);
                String m = mime == null || mime.isEmpty() || mime.equals("application/octet-stream") ? guessMime(f.getName()) : mime;
                Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(u, m).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(i, "Открыть с помощью"));
            } catch (Exception e) { toast("Нет приложения, чтобы открыть этот файл"); }
        });
    }

    @Override
    public void shareFile(File f, String mime) {
        ui.post(() -> {
            try {
                Uri u = uriFor(f);
                Intent i = new Intent(Intent.ACTION_SEND).setType(mime == null || mime.isEmpty() ? guessMime(f.getName()) : mime)
                        .putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                i.setClipData(ClipData.newRawUri(f.getName(), u));
                startActivity(Intent.createChooser(i, "Отправить"));
            } catch (Exception e) { toast("Не удалось поделиться файлом"); }
        });
    }

    @Override
    public String saveDownload(File f, String name, String mime) throws Exception {
        name = Core.safeName(name);
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime == null || mime.isEmpty() ? guessMime(name) : mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) throw new Exception("Не удалось создать файл в «Загрузках»");
            try (InputStream in = new FileInputStream(f); OutputStream os = getContentResolver().openOutputStream(u)) {
                byte[] b = new byte[65536];
                int n;
                while ((n = in.read(b)) > 0) os.write(b, 0, n);
            }
            String shown = name;
            try (Cursor c = getContentResolver().query(u, new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) shown = c.getString(0);
            } catch (Exception ignored) { }
            return "Загрузки/" + shown;
        }
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ui.post(() -> requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE));
            throw new Exception("Разрешите доступ к памяти и нажмите «Сохранить» ещё раз");
        }
        File d = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File out = Core.uniq(d, name);
        try (InputStream in = new FileInputStream(f); OutputStream os = new FileOutputStream(out)) {
            byte[] b = new byte[65536];
            int n;
            while ((n = in.read(b)) > 0) os.write(b, 0, n);
        }
        MediaScannerConnection.scanFile(this, new String[]{out.getAbsolutePath()}, null, null);
        return "Download/" + out.getName();
    }

    /* ================= JS bridge ================= */
    class Bridge {
        @JavascriptInterface public int sdk() { return Build.VERSION.SDK_INT; }

        @JavascriptInterface public String accounts() { return core.accounts().toString(); }

        @JavascriptInterface
        public void call(String id, String method, String args) {
            core.net.execute(() -> {
                JSONObject e = Core.ev("res");
                try {
                    e.put("id", id);
                    Object r = core.call(method, new JSONObject(args == null || args.isEmpty() ? "{}" : args), MainActivity.this);
                    e.put("ok", true);
                    e.put("data", r == null ? JSONObject.NULL : r);
                } catch (Throwable t) {
                    try { e.put("ok", false); e.put("error", t.getMessage() == null ? t.toString() : t.getMessage()); } catch (Exception ignored) { }
                }
                emit(e);
                if (method.equals("addAccount") || method.equals("removeAccount")) MailJob.schedule(MainActivity.this);
            });
        }

        @JavascriptInterface public boolean cancelSend(String id) { return core.cancelSend(id); }

        @JavascriptInterface
        public String takeIntent() {
            synchronized (MainActivity.this) {
                String r = pending == null ? "" : pending.toString();
                pending = null;
                return r;
            }
        }

        @JavascriptInterface public void openUrl(String url) { ui.post(() -> MainActivity.this.openUrl(url)); }

        @JavascriptInterface
        public void pickFiles(String id) {
            ui.post(() -> {
                try {
                    pickReq = id;
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(i, REQ_PICK);
                } catch (Exception e) {
                    try {
                        Intent i = new Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                        startActivityForResult(i, REQ_PICK);
                    } catch (Exception e2) { toast("Нет приложения для выбора файлов"); }
                }
            });
        }

        @JavascriptInterface public String getPref(String k) { return core.prefs().getString("p_" + k, ""); }

        @JavascriptInterface
        public void setPref(String k, String v) {
            core.prefs().edit().putString("p_" + k, v).apply();
            if (k.equals("notifyEvery")) MailJob.schedule(MainActivity.this);
        }

        @JavascriptInterface
        public boolean notifyAllowed() {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false;
            return getSystemService(NotificationManager.class).areNotificationsEnabled();
        }

        @JavascriptInterface
        public void askNotify() {
            ui.post(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                else if (!getSystemService(NotificationManager.class).areNotificationsEnabled()) {
                    try { startActivity(new Intent("android.settings.APP_NOTIFICATION_SETTINGS").putExtra("android.provider.extra.APP_PACKAGE", getPackageName())); } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface public void toast(String t) { MainActivity.this.toast(t); }

        @JavascriptInterface public void checkNow() { core.net.execute(core::checkNew); }

        @JavascriptInterface
        public void shareText(String subject, String text) {
            ui.post(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, subject).putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "Поделиться"));
                } catch (Exception ignored) { }
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        JSONObject e = Core.ev("perm");
        try { e.put("req", req == REQ_NOTIF ? "notify" : "storage"); e.put("granted", res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED); } catch (Exception ignored) { }
        emit(e);
    }
}
